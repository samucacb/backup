<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre - Sistema de Ensalamento</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-building"></i> Sistema de Ensalamento
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="bi bi-house"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="salas.php">
                            <i class="bi bi-door-open"></i> Salas
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="turmas.php">
                            <i class="bi bi-people"></i> Turmas
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ensalamento.php">
                            <i class="bi bi-calendar-check"></i> Ensalamento
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="relatorios.php">
                            <i class="bi bi-graph-up"></i> Relatórios
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" href="sobre.php">
                            <i class="bi bi-info-circle"></i> Sobre
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Header -->
        <div class="row mb-4">
            <div class="col text-center">
                <h1 class="h2 mb-3">
                    <i class="bi bi-building text-primary"></i>
                    Sistema de Ensalamento
                </h1>
                <p class="lead text-muted">Solução inteligente para otimização de alocação de salas</p>
                <span class="badge bg-primary fs-6">Versão 1.0.0</span>
            </div>
        </div>

        <div class="row">
            <!-- Informações do Sistema -->
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="bi bi-info-circle"></i> Sobre o Sistema
                        </h5>
                    </div>
                    <div class="card-body">
                        <p>O <strong>Sistema de Ensalamento</strong> é uma solução completa e inteligente desenvolvida para otimizar a alocação de salas de aula em instituições educacionais.</p>
                        
                        <p>Utilizando algoritmos avançados de otimização, o sistema analisa as características das salas, requisitos das turmas e restrições operacionais para encontrar a melhor distribuição possível, maximizando a eficiência e minimizando conflitos.</p>
                        
                        <h6 class="mt-4">Principais Características:</h6>
                        <ul>
                            <li><strong>Algoritmos Inteligentes:</strong> Três algoritmos diferentes (Guloso, Otimizado e Híbrido) para atender diferentes necessidades</li>
                            <li><strong>Cálculo de Ponto Ótimo:</strong> Determina automaticamente quando é vantajoso dobrar turmas</li>
                            <li><strong>Detecção de Conflitos:</strong> Identifica e resolve automaticamente conflitos de horário e capacidade</li>
                            <li><strong>Relatórios Avançados:</strong> Analytics detalhados com gráficos e métricas de performance</li>
                            <li><strong>Interface Intuitiva:</strong> Design moderno e responsivo para facilitar o uso</li>
                            <li><strong>Backup Automático:</strong> Sistema de backup e restauração integrado</li>
                        </ul>
                        
                        <h6 class="mt-4">Benefícios:</h6>
                        <div class="row">
                            <div class="col-md-6">
                                <ul>
                                    <li>Redução de conflitos de horário</li>
                                    <li>Otimização do uso de espaços</li>
                                    <li>Economia de tempo na gestão</li>
                                    <li>Melhoria na qualidade do ensino</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul>
                                    <li>Relatórios detalhados para tomada de decisão</li>
                                    <li>Flexibilidade para diferentes cenários</li>
                                    <li>Interface amigável e intuitiva</li>
                                    <li>Integração com sistemas existentes</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tecnologias Utilizadas -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="bi bi-code-square"></i> Tecnologias Utilizadas
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Backend:</h6>
                                <ul class="list-unstyled">
                                    <li><i class="bi bi-check-circle text-success me-2"></i>PHP 8.0+</li>
                                    <li><i class="bi bi-check-circle text-success me-2"></i>MySQL 8.0+</li>
                                    <li><i class="bi bi-check-circle text-success me-2"></i>PDO para acesso a dados</li>
                                    <li><i class="bi bi-check-circle text-success me-2"></i>APIs RESTful</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h6>Frontend:</h6>
                                <ul class="list-unstyled">
                                    <li><i class="bi bi-check-circle text-success me-2"></i>HTML5 / CSS3</li>
                                    <li><i class="bi bi-check-circle text-success me-2"></i>Bootstrap 5</li>
                                    <li><i class="bi bi-check-circle text-success me-2"></i>JavaScript ES6+</li>
                                    <li><i class="bi bi-check-circle text-success me-2"></i>Chart.js para gráficos</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Algoritmos -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="bi bi-cpu"></i> Algoritmos de Ensalamento
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="text-center mb-3">
                                    <i class="bi bi-lightning-charge text-warning fs-1"></i>
                                    <h6>Algoritmo Guloso</h6>
                                </div>
                                <p class="small">Execução rápida com boa eficiência. Ideal para cenários simples com poucas restrições. Prioriza a primeira opção viável encontrada.</p>
                                <ul class="small">
                                    <li>Velocidade: ⭐⭐⭐⭐⭐</li>
                                    <li>Qualidade: ⭐⭐⭐</li>
                                    <li>Uso de recursos: ⭐⭐</li>
                                </ul>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="text-center mb-3">
                                    <i class="bi bi-gear text-primary fs-1"></i>
                                    <h6>Algoritmo Otimizado</h6>
                                </div>
                                <p class="small">Analisa todas as possibilidades para encontrar a melhor alocação. Recomendado para obter os melhores resultados em cenários complexos.</p>
                                <ul class="small">
                                    <li>Velocidade: ⭐⭐⭐</li>
                                    <li>Qualidade: ⭐⭐⭐⭐⭐</li>
                                    <li>Uso de recursos: ⭐⭐⭐⭐</li>
                                </ul>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="text-center mb-3">
                                    <i class="bi bi-shuffle text-success fs-1"></i>
                                    <h6>Algoritmo Híbrido</h6>
                                </div>
                                <p class="small">Combina velocidade e qualidade, oferecendo um bom equilíbrio entre tempo de execução e resultado. Ideal para a maioria dos casos.</p>
                                <ul class="small">
                                    <li>Velocidade: ⭐⭐⭐⭐</li>
                                    <li>Qualidade: ⭐⭐⭐⭐</li>
                                    <li>Uso de recursos: ⭐⭐⭐</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-md-4">
                <!-- Informações Técnicas -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="bi bi-info-square"></i> Informações Técnicas
                        </h6>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm">
                            <tr>
                                <td><strong>Versão:</strong></td>
                                <td>1.0.0</td>
                            </tr>
                            <tr>
                                <td><strong>Lançamento:</strong></td>
                                <td>Janeiro 2025</td>
                            </tr>
                            <tr>
                                <td><strong>Licença:</strong></td>
                                <td>Proprietária</td>
                            </tr>
                            <tr>
                                <td><strong>Suporte:</strong></td>
                                <td>PHP 8.0+</td>
                            </tr>
                            <tr>
                                <td><strong>Banco:</strong></td>
                                <td>MySQL 8.0+</td>
                            </tr>
                            <tr>
                                <td><strong>Navegadores:</strong></td>
                                <td>Modernos</td>
                            </tr>
                        </table>
                    </div>
                </div>

                <!-- Estatísticas -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="bi bi-graph-up"></i> Estatísticas do Sistema
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-6">
                                <h4 class="text-primary mb-0" id="total-salas-sobre">-</h4>
                                <small class="text-muted">Salas Cadastradas</small>
                            </div>
                            <div class="col-6">
                                <h4 class="text-info mb-0" id="total-turmas-sobre">-</h4>
                                <small class="text-muted">Turmas Ativas</small>
                            </div>
                        </div>
                        <hr>
                        <div class="row text-center">
                            <div class="col-6">
                                <h4 class="text-success mb-0" id="total-ensalamentos-sobre">-</h4>
                                <small class="text-muted">Ensalamentos</small>
                            </div>
                            <div class="col-6">
                                <h4 class="text-warning mb-0" id="eficiencia-media-sobre">-</h4>
                                <small class="text-muted">Eficiência Média</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Suporte -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="bi bi-headset"></i> Suporte e Contato
                        </h6>
                    </div>
                    <div class="card-body">
                        <p class="small text-muted">Para suporte técnico, dúvidas ou sugestões:</p>
                        
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <i class="bi bi-envelope text-primary me-2"></i>
                                <a href="mailto:suporte@sistema.local">suporte@sistema.local</a>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-telephone text-success me-2"></i>
                                <a href="tel:+5511123456789">(11) 1234-5678</a>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-globe text-info me-2"></i>
                                <a href="http://www.sistema.local" target="_blank">www.sistema.local</a>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-file-text text-warning me-2"></i>
                                <a href="README.md" target="_blank">Documentação</a>
                            </li>
                        </ul>
                        
                        <hr>
                        
                        <div class="text-center">
                            <button type="button" class="btn btn-outline-primary btn-sm" onclick="verificarAtualizacoes()">
                                <i class="bi bi-arrow-clockwise"></i> Verificar Atualizações
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Créditos -->
                <div class="card">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="bi bi-heart"></i> Créditos
                        </h6>
                    </div>
                    <div class="card-body">
                        <p class="small text-muted">Desenvolvido com ❤️ para facilitar a gestão educacional.</p>
                        
                        <p class="small">
                            <strong>Desenvolvedor:</strong><br>
                            Sistema de Ensalamento Team
                        </p>
                        
                        <p class="small">
                            <strong>Agradecimentos:</strong><br>
                            • Bootstrap Team<br>
                            • Chart.js Contributors<br>
                            • PHP Community<br>
                            • MySQL Team
                        </p>
                        
                        <div class="text-center mt-3">
                            <small class="text-muted">
                                © 2025 Sistema de Ensalamento<br>
                                Todos os direitos reservados
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Inicialização
        document.addEventListener('DOMContentLoaded', function() {
            carregarEstatisticas();
        });

        function carregarEstatisticas() {
            fetch('api/dashboard.php?action=estatisticas')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        atualizarEstatisticas(data.data);
                    }
                })
                .catch(error => {
                    console.error('Erro ao carregar estatísticas:', error);
                });
        }

        function atualizarEstatisticas(stats) {
            document.getElementById('total-salas-sobre').textContent = stats.total_salas || 0;
            document.getElementById('total-turmas-sobre').textContent = stats.total_turmas || 0;
            document.getElementById('total-ensalamentos-sobre').textContent = stats.total_ensalamentos || 0;
            document.getElementById('eficiencia-media-sobre').textContent = stats.eficiencia_media ? stats.eficiencia_media + '%' : '-';
        }

        function verificarAtualizacoes() {
            // Simular verificação de atualizações
            const btn = event.target;
            const originalText = btn.innerHTML;
            
            btn.innerHTML = '<i class="bi bi-arrow-clockwise spin"></i> Verificando...';
            btn.disabled = true;
            
            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.disabled = false;
                alert('Sistema atualizado! Você está usando a versão mais recente.');
            }, 2000);
        }
    </script>
    
    <style>
        .spin {
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    </style>
</body>
</html>

