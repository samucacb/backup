# Sistema de Ensalamento - PHP/MySQL

Sistema web completo para gerenciamento e otimização de ensalamento de turmas, desenvolvido em PHP com banco de dados MySQL.

## 🎯 Funcionalidades Principais

### ✅ **Gestão de Salas**
- Cadastro completo de salas com capacidade e tipo
- Classificação por tipo (comum, laboratório, auditório, prática, informática)
- Controle de disponibilidade e localização
- Validação de capacidade e recursos

### ✅ **Gestão de Turmas**
- Cadastro de turmas com informações detalhadas
- Controle de número de alunos e professor
- Classificação por curso e tipo de aula
- Gestão por período letivo

### ✅ **Algoritmos de Ensalamento**
- **Algoritmo Guloso**: Rápido e eficiente para casos simples
- **Algoritmo Otimizado**: Melhor resultado com análise completa
- **Algoritmo Híbrido**: Combina velocidade e qualidade
- Detecção e resolução automática de conflitos

### ✅ **Cálculo de Ponto Ótimo de Dobra**
- Análise automática para recomendação de dobra de turmas
- Consideração de tipo de aula (teórica/prática)
- Otimização de recursos e capacidade
- Relatórios de recomendações

### ✅ **Sistema de Relatórios Avançados**
- Dashboard com métricas em tempo real
- Gráficos interativos de ocupação e eficiência
- Relatórios detalhados por período, curso e sala
- Exportação em CSV, JSON e PDF
- Analytics de performance do sistema

### ✅ **Interface Web Moderna**
- Design responsivo com Bootstrap 5
- Interface intuitiva e profissional
- Gráficos interativos com Chart.js
- Navegação fluida e experiência otimizada

## 🚀 Instalação Rápida

### Pré-requisitos
- PHP 7.4 ou superior
- MySQL 5.7 ou MariaDB 10.3+
- Servidor web (Apache/Nginx)
- Extensão PDO MySQL habilitada

### Instalação Automática

1. **Extrair arquivos**
   ```bash
   # Extrair o sistema no diretório web
   unzip sistema-ensalamento-php.zip -d /var/www/html/ensalamento/
   cd /var/www/html/ensalamento/
   ```

2. **Executar instalador**
   ```
   Acesse: http://localhost/ensalamento/install.php
   ```

3. **Seguir assistente de instalação**
   - Verificação de requisitos
   - Configuração do banco de dados
   - Criação da estrutura
   - Configuração do usuário administrador

4. **Acessar sistema**
   ```
   URL: http://localhost/ensalamento/
   Usuário: admin
   Senha: admin123 (configurável na instalação)
   ```

### Instalação Manual

1. **Criar banco de dados**
   ```sql
   CREATE DATABASE ensalamento CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

2. **Importar estrutura**
   ```bash
   mysql -u root -p ensalamento < database/schema.sql
   ```

3. **Configurar conexão**
   ```php
   // Editar config/database.php
   $db_config = [
       'host' => 'localhost',
       'dbname' => 'ensalamento',
       'username' => 'seu_usuario',
       'password' => 'sua_senha'
   ];
   ```

## 📁 Estrutura do Projeto

```
ensalamento-php/
├── api/                    # APIs REST
│   ├── dashboard.php       # API do dashboard
│   ├── ensalamento.php     # API de ensalamento
│   └── relatorios.php      # API de relatórios
├── assets/                 # Recursos estáticos
│   ├── css/
│   │   └── style.css       # Estilos personalizados
│   └── js/                 # Scripts JavaScript
├── classes/                # Classes PHP
│   ├── AlgoritmoEnsalamento.php
│   ├── Ensalamento.php
│   ├── Sala.php
│   └── Turma.php
├── config/                 # Configurações
│   └── database.php        # Configuração do banco
├── database/               # Scripts de banco
│   └── schema.sql          # Estrutura do banco
├── index.php               # Dashboard principal
├── salas.php               # Gestão de salas
├── turmas.php              # Gestão de turmas
├── ensalamento.php         # Execução de ensalamento
├── relatorios.php          # Relatórios e analytics
├── install.php             # Instalador automático
└── README.md               # Esta documentação
```

## 🔧 Configuração Avançada

### Parâmetros do Sistema

O sistema permite configuração através da tabela `configuracoes`:

```sql
-- Período letivo atual
UPDATE configuracoes SET valor = '2025.1' WHERE chave = 'periodo_atual';

-- Algoritmo padrão
UPDATE configuracoes SET valor = 'otimizado' WHERE chave = 'algoritmo_padrao';

-- Timeout para ensalamento (segundos)
UPDATE configuracoes SET valor = '300' WHERE chave = 'timeout_ensalamento';
```

### Algoritmos Disponíveis

1. **Guloso (`guloso`)**
   - Mais rápido
   - Boa para cenários simples
   - Complexidade: O(n log n)

2. **Otimizado (`otimizado`)**
   - Melhor resultado
   - Análise completa de conflitos
   - Complexidade: O(n²)

3. **Híbrido (`hibrido`)**
   - Equilibrio entre velocidade e qualidade
   - Combina os dois algoritmos
   - Complexidade: O(n log n) + O(k²) onde k < n

### Personalização de Interface

```css
/* Personalizar cores em assets/css/style.css */
:root {
    --primary-color: #0d6efd;    /* Azul principal */
    --success-color: #198754;    /* Verde sucesso */
    --warning-color: #ffc107;    /* Amarelo aviso */
    --danger-color: #dc3545;     /* Vermelho erro */
}
```

## 📊 Uso do Sistema

### 1. Cadastro de Salas

```
Menu: Salas > Nova Sala
- Código: Identificador único (ex: A101)
- Nome: Nome descritivo
- Capacidade: Número máximo de alunos
- Tipo: comum, laboratório, auditório, prática, informática
- Localização: Descrição da localização
```

### 2. Cadastro de Turmas

```
Menu: Turmas > Nova Turma
- Código: Identificador único (ex: MAT101)
- Nome: Nome da disciplina
- Número de Alunos: Quantidade atual
- Professor: Nome do professor
- Curso: Curso da turma
- Tipo de Aula: teórica ou prática
- Período: Período letivo
```

### 3. Execução de Ensalamento

```
Menu: Ensalamento > Executar
- Selecionar período letivo
- Escolher algoritmo (guloso/otimizado/híbrido)
- Configurar parâmetros avançados
- Executar e acompanhar progresso
```

### 4. Análise de Resultados

```
Menu: Relatórios
- Visualizar métricas de eficiência
- Analisar conflitos e problemas
- Exportar relatórios
- Verificar recomendações de dobra
```

## 🔍 Funcionalidades Avançadas

### Ponto Ótimo de Dobra

O sistema analisa automaticamente cada turma e fornece recomendações:

- **Manter**: Turma está no tamanho ideal
- **Dobrar Recomendado**: Benefício em dividir a turma
- **Dobrar Obrigatório**: Turma excede capacidade máxima
- **Juntar Recomendado**: Turmas pequenas podem ser unificadas

### Detecção de Conflitos

- **Conflitos de Horário**: Mesma sala, mesmo horário
- **Superlotação**: Mais alunos que capacidade da sala
- **Incompatibilidade**: Tipo de aula incompatível com sala
- **Recursos Insuficientes**: Sala não atende requisitos

### Sistema de Logs

Todas as operações são registradas para auditoria:

```sql
SELECT * FROM logs 
WHERE acao = 'INSERT' AND tabela = 'ensalamento' 
ORDER BY created_at DESC;
```

## 📈 Métricas e KPIs

### Indicadores Principais

- **Taxa de Alocação**: % de turmas alocadas com sucesso
- **Eficiência Média**: Aproveitamento médio das salas
- **Taxa de Conflitos**: % de turmas com conflitos
- **Utilização de Salas**: % de salas utilizadas

### Relatórios Disponíveis

1. **Visão Geral**: Estatísticas gerais do período
2. **Ocupação de Salas**: Análise por sala e horário
3. **Eficiência**: Ranking de eficiência por sala
4. **Conflitos**: Lista detalhada de problemas
5. **Ponto Ótimo**: Recomendações de dobra

## 🛠️ Manutenção

### Backup Automático

```sql
-- Configurar backup automático
UPDATE configuracoes SET valor = '1' WHERE chave = 'backup_automatico';
```

### Limpeza de Dados

```sql
-- Limpar logs antigos (mais de 90 dias)
DELETE FROM logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY);

-- Limpar ensalamentos de períodos antigos
DELETE FROM ensalamento WHERE periodo < '2024.1';
```

### Otimização de Performance

```sql
-- Índices recomendados
CREATE INDEX idx_ensalamento_periodo ON ensalamento(periodo);
CREATE INDEX idx_ensalamento_sala_horario ON ensalamento(sala_id, dia_semana, horario_inicio);
CREATE INDEX idx_turmas_periodo ON turmas(periodo);
```

## 🔒 Segurança

### Configurações Recomendadas

1. **Remover install.php** após instalação
2. **Configurar HTTPS** em produção
3. **Backup regular** do banco de dados
4. **Atualizar senhas** padrão
5. **Configurar firewall** adequado

### Permissões de Arquivo

```bash
# Permissões recomendadas
chmod 644 *.php
chmod 755 assets/
chmod 600 config/database.php
```

## 🆘 Solução de Problemas

### Problemas Comuns

**Erro de Conexão com Banco**
```
Verificar: config/database.php
Testar: mysql -u usuario -p banco
```

**Timeout no Ensalamento**
```sql
UPDATE configuracoes SET valor = '600' WHERE chave = 'timeout_ensalamento';
```

**Conflitos Persistentes**
```
1. Verificar dados de entrada
2. Executar validação manual
3. Ajustar parâmetros do algoritmo
```

### Logs de Debug

```php
// Habilitar logs detalhados
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
```

## 📞 Suporte

### Informações do Sistema

- **Versão**: 1.0.0
- **PHP Mínimo**: 7.4
- **MySQL Mínimo**: 5.7
- **Licença**: MIT

### Recursos Adicionais

- Documentação técnica completa
- Scripts de exemplo
- Dados de teste inclusos
- Suporte para customização

---

**Sistema desenvolvido para otimização de ensalamento educacional**
*Simples, eficiente e completo* ✨

