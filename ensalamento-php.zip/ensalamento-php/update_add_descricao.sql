-- Script para adicionar coluna descricao na tabela salas
-- Execute este script se você já tem o sistema instalado

ALTER TABLE salas ADD COLUMN descricao TEXT AFTER tipo;
