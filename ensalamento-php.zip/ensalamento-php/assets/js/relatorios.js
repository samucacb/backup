/**
 * JavaScript para Relaterios
 * Sistema de Ensalamento
 */

// Variaveis globais para graficos
let chartOcupacao = null;
let chartEficiencia = null;
let chartTendencia = null;

// Inicializacao
document.addEventListener('DOMContentLoaded', function() {
    carregarRelatorios();
    
    // Event listeners
    document.getElementById('periodo-select')?.addEventListener('change', atualizarRelatorios);
    document.getElementById('tipo-relatorio')?.addEventListener('change', atualizarRelatorios);
    document.getElementById('btn-exportar-pdf')?.addEventListener('click', exportarPDF);
    document.getElementById('btn-exportar-excel')?.addEventListener('click', exportarExcel);
});

function carregarRelatorios() {
    carregarMetricas();
    carregarGraficos();
    carregarTabelaDetalhada();
}

function carregarMetricas() {
    const periodo = document.getElementById('periodo-select')?.value || '2025.1';
    
    fetch(`api/relatorios.php?action=metricas&periodo=${periodo}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                atualizarCards(data.data);
            } else {
                console.error('Erro ao carregar metricas:', data.message);
            }
        })
        .catch(error => {
            console.error('Erro na comunicacao:', error);
        });
}

function carregarGraficos() {
    const periodo = document.getElementById('periodo-select')?.value || '2025.1';
    
    // Grafico de Ocupacao
    fetch(`api/relatorios.php?action=grafico_ocupacao&periodo=${periodo}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                criarGraficoOcupacao(data.data);
            }
        })
        .catch(error => console.error('Erro ao carregar grafico de ocupacao:', error));
    
    // Grafico de Eficiencia
    fetch(`api/relatorios.php?action=grafico_eficiencia&periodo=${periodo}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                criarGraficoEficiencia(data.data);
            }
        })
        .catch(error => console.error('Erro ao carregar grafico de eficiencia:', error));
    
    // Grafico de Tendencia
    fetch(`api/relatorios.php?action=grafico_tendencia&periodo=${periodo}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                criarGraficoTendencia(data.data);
            }
        })
        .catch(error => console.error('Erro ao carregar grafico de tendencia:', error));
}

function carregarTabelaDetalhada() {
    const periodo = document.getElementById('periodo-select')?.value || '2025.1';
    const tipo = document.getElementById('tipo-relatorio')?.value || 'ocupacao';
    
    fetch(`api/relatorios.php?action=tabela_detalhada&periodo=${periodo}&tipo=${tipo}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                atualizarTabelaDetalhada(data.data);
            } else {
                console.error('Erro ao carregar tabela:', data.message);
            }
        })
        .catch(error => {
            console.error('Erro na comunicacao:', error);
        });
}

function atualizarCards(metricas) {
    // Um objeto mapeando o ID do elemento para a chave correspondente nos dados das métricas
    const metricasMap = {
        'total-salas': metricas.total_salas || 0,
        'salas-ocupadas': metricas.salas_ocupadas || 0,
        'taxa-ocupacao': (metricas.taxa_ocupacao || 0) + '%',
        'eficiencia-media': (metricas.eficiencia_media || 0) + '%',
        'total-turmas': metricas.total_turmas || 0,
        'turmas-alocadas': metricas.turmas_alocadas || 0,
        'conflitos': metricas.conflitos || 0,
        'capacidade-total': metricas.capacidade_total || 0
    };

    // Itera sobre o mapa e atualiza cada elemento que existir
    for (const id in metricasMap) {
        const elemento = document.getElementById(id);
        if (elemento) {
            elemento.textContent = metricasMap[id];
        }
    }
}

function criarGraficoOcupacao(dados) {
    const ctx = document.getElementById('chart-ocupacao')?.getContext('2d');
    if (!ctx) return;
    
    // Destruir grafico existente
    if (chartOcupacao) {
        chartOcupacao.destroy();
    }
    
    chartOcupacao = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: dados.labels || [],
            datasets: [{
                label: 'Taxa de Ocupacao (%)',
                data: dados.values || [],
                backgroundColor: 'rgba(54, 162, 235, 0.8)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                    text: 'Taxa de Ocupacao por Sala'
                }
            }
        }
    });
}

function criarGraficoEficiencia(dados) {
    const ctx = document.getElementById('chart-eficiencia')?.getContext('2d');
    if (!ctx) return;
    
    // Destruir grafico existente
    if (chartEficiencia) {
        chartEficiencia.destroy();
    }
    
    chartEficiencia = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: dados.labels || [],
            datasets: [{
                data: dados.values || [],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.8)',
                    'rgba(54, 162, 235, 0.8)',
                    'rgba(255, 205, 86, 0.8)',
                    'rgba(75, 192, 192, 0.8)',
                    'rgba(153, 102, 255, 0.8)'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Distribuicao de Eficiencia'
                }
            }
        }
    });
}

function criarGraficoTendencia(dados) {
    const ctx = document.getElementById('chart-tendencia')?.getContext('2d');
    if (!ctx) return;
    
    // Destruir grafico existente
    if (chartTendencia) {
        chartTendencia.destroy();
    }
    
    chartTendencia = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dados.labels || [],
            datasets: [{
                label: 'Ocupacao Media (%)',
                data: dados.ocupacao || [],
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                tension: 0.1
            }, {
                label: 'Eficiencia Media (%)',
                data: dados.eficiencia || [],
                borderColor: 'rgba(255, 99, 132, 1)',
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            plugins: {
                title: {
                    display: true,
                    text: 'Tendencia de Ocupacao e Eficiencia'
                }
            }
        }
    });
}

function atualizarTabelaDetalhada(dados) {
    const tbody = document.getElementById('tabela-detalhada-body');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    if (!dados || dados.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Nenhum dado encontrado</td></tr>';
        return;
    }
    
    dados.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.sala_codigo || '-'}</td>
            <td>${item.sala_nome || '-'}</td>
            <td>${item.capacidade || 0}</td>
            <td>${item.aulas_alocadas || 0}</td>
            <td>
                <div class="progress" style="height: 20px;">
                    <div class="progress-bar" role="progressbar" 
                         style="width: ${item.taxa_ocupacao || 0}%" 
                         aria-valuenow="${item.taxa_ocupacao || 0}" 
                         aria-valuemin="0" aria-valuemax="100">
                        ${(item.taxa_ocupacao || 0).toFixed(1)}%
                    </div>
                </div>
            </td>
            <td>
                <span class="badge ${getEficienciaClass(item.eficiencia)}">
                    ${(item.eficiencia || 0).toFixed(1)}%
                </span>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function getEficienciaClass(eficiencia) {
    if (eficiencia >= 80) return 'bg-success';
    if (eficiencia >= 60) return 'bg-warning';
    return 'bg-danger';
}

function atualizarRelatorios() {
    carregarRelatorios();
}

function exportarPDF() {
    const periodo = document.getElementById('periodo-select')?.value || '2025.1';
    const tipo = document.getElementById('tipo-relatorio')?.value || 'ocupacao';
    
    window.open(`api/relatorios.php?action=exportar&formato=pdf&periodo=${periodo}&tipo=${tipo}`, '_blank');
}

function exportarExcel() {
    const periodo = document.getElementById('periodo-select')?.value || '2025.1';
    const tipo = document.getElementById('tipo-relatorio')?.value || 'ocupacao';
    
    window.open(`api/relatorios.php?action=exportar&formato=excel&periodo=${periodo}&tipo=${tipo}`, '_blank');
}

// Funcao para atualizar dados em tempo real
function atualizarDadosTempoReal() {
    carregarMetricas();
}

// Atualizar a cada 30 segundos
setInterval(atualizarDadosTempoReal, 30000);

