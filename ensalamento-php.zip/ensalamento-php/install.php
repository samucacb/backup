<?php
/**
 * Script de Instalação do Sistema de Ensalamento
 * Versão: 1.0 - Corrigido
 */

header('Content-Type: application/json; charset=utf-8');

// Desabilitar exibição de erros para evitar HTML na resposta JSON
ini_set('display_errors', 0);
ini_set('log_errors', 1);

try {
    $action = $_GET['action'] ?? $_POST['action'] ?? '';
    
    switch ($action) {
        case 'verificar_requisitos':
            verificarRequisitos();
            break;
            
        case 'testar_conexao':
            testarConexaoDatabase();
            break;
            
        case 'instalar':
            executarInstalacao();
            break;
            
        case 'finalizar':
            finalizarInstalacao();
            break;
            
        default:
            exibirPaginaInstalacao();
            break;
    }
    
} catch (Exception $e) {
    if (isset($_GET['action']) || isset($_POST['action'])) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    } else {
        die('Erro: ' . $e->getMessage());
    }
}

function verificarRequisitos() {
    $requisitos = [
        'php_version' => version_compare(PHP_VERSION, '7.4.0', '>='),
        'pdo_mysql' => extension_loaded('pdo_mysql'),
        'json' => extension_loaded('json'),
        'mbstring' => extension_loaded('mbstring'),
        'writable' => is_writable(__DIR__)
    ];
    
    $todos_ok = !in_array(false, $requisitos);
    
    echo json_encode([
        'success' => true,
        'data' => [
            'requisitos' => $requisitos,
            'todos_ok' => $todos_ok,
            'php_version' => PHP_VERSION
        ]
    ]);
}

function testarConexaoDatabase() {
    $host = $_POST['host'] ?? 'localhost';
    $port = $_POST['port'] ?? '3306';
    $database = $_POST['database'] ?? 'ensalamento';
    $username = $_POST['username'] ?? 'root';
    $password = $_POST['password'] ?? '';
    
    try {
        $pdo = new PDO(
            "mysql:host={$host};port={$port};dbname={$database};charset=utf8mb4",
            $username,
            $password,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]
        );
        
        // Salvar configurações
        salvarConfiguracaoDatabase($host, $port, $database, $username, $password);
        
        echo json_encode([
            'success' => true,
            'message' => 'Conexão estabelecida com sucesso!'
        ]);
        
    } catch (PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Erro de conexão: ' . $e->getMessage()
        ]);
    }
}

function executarInstalacao() {
    try {
        require_once __DIR__ . '/config/database.php';
        
        // Verificar se já existem tabelas
        $tabelas_existentes = verificarTabelasExistentes($database);
        
        if (!empty($tabelas_existentes) && !isset($_GET['force_update'])) {
            echo json_encode([
                'success' => false,
                'action_required' => 'confirm_update',
                'message' => 'Já existem tabelas no banco. Deseja atualizar/recriar as tabelas?'
            ]);
            return;
        }
        
        // Executar instalação
        executarInstalacaoCompleta($database);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Erro na instalação: ' . $e->getMessage()
        ]);
    }
}

function verificarTabelasExistentes($database) {
    try {
        $stmt = $database->query("SHOW TABLES");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {
        return [];
    }
}

function executarInstalacaoCompleta($database) {
    // Ler e executar schema SQL
    $schema = file_get_contents(__DIR__ . '/database/schema.sql');
    
    if ($schema === false) {
        throw new Exception('Não foi possível ler o arquivo schema.sql');
    }
    
    // Dividir em comandos individuais
    $comandos = explode(';', $schema);
    
    $database->beginTransaction();
    
    try {
        foreach ($comandos as $comando) {
            $comando = trim($comando);
            
            if (empty($comando) || substr($comando, 0, 2) === '--') {
                continue;
            }
            
            $database->exec($comando);
        }
        
        // Executar dados iniciais
        $dados_iniciais = file_get_contents(__DIR__ . '/database/dados_iniciais.sql');
        
        if ($dados_iniciais !== false) {
            $comandos_dados = explode(';', $dados_iniciais);
            
            foreach ($comandos_dados as $comando) {
                $comando = trim($comando);
                
                if (empty($comando) || substr($comando, 0, 2) === '--') {
                    continue;
                }
                
                $database->exec($comando);
            }
        }
        
        $database->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Instalação concluída com sucesso'
        ]);
        
    } catch (Exception $e) {
        $database->rollback();
        throw new Exception('Erro ao executar schema: ' . $e->getMessage());
    }
}

function salvarConfiguracaoDatabase($host, $port, $database, $username, $password) {
    // Criar diretório config se não existir
    if (!is_dir(__DIR__ . '/config')) {
        mkdir(__DIR__ . '/config', 0755, true);
    }
    
    $config = "<?php
/**
 * Configuração do Banco de Dados
 * Gerado automaticamente pelo instalador
 */

try {
    \$database = new PDO(
        'mysql:host={$host};port={$port};dbname={$database};charset=utf8mb4',
        '{$username}',
        '{$password}',
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4'
        ]
    );
} catch (PDOException \$e) {
    die('Erro de conexão: ' . \$e->getMessage());
}
?>";
    
    if (!file_put_contents(__DIR__ . '/config/database.php', $config)) {
        throw new Exception('Não foi possível salvar configurações do banco');
    }
}

function finalizarInstalacao() {
    // Criar arquivo de instalação concluída
    $info = [
        'instalado_em' => date('Y-m-d H:i:s'),
        'versao' => '1.0.0',
        'php_version' => PHP_VERSION
    ];
    
    file_put_contents(__DIR__ . '/.installed', json_encode($info));
    
    echo json_encode([
        'success' => true,
        'message' => 'Sistema instalado com sucesso!',
        'redirect' => 'index.php'
    ]);
}

function exibirPaginaInstalacao() {
    // Se já está instalado, redirecionar
    if (file_exists(__DIR__ . '/.installed')) {
        header('Location: index.php');
        exit;
    }
    
    // Retornar HTML da página de instalação
    header('Content-Type: text/html; charset=utf-8');
    ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalação - Sistema de Ensalamento</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white text-center">
                        <h3><i class="bi bi-gear"></i> Instalação do Sistema de Ensalamento</h3>
                    </div>
                    <div class="card-body">
                        <!-- Progresso -->
                        <div class="mb-4">
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" style="width: 0%" id="progresso"></div>
                            </div>
                            <div class="mt-2 text-center">
                                <small class="text-muted" id="etapa-atual">Iniciando instalação...</small>
                            </div>
                        </div>
                        
                        <!-- Etapa 1: Verificação de Requisitos -->
                        <div id="etapa-1" class="etapa">
                            <h5><i class="bi bi-check-circle"></i> 1. Verificação de Requisitos</h5>
                            <div id="requisitos-lista">
                                <div class="text-center">
                                    <div class="spinner-border text-primary" role="status">
                                        <span class="visually-hidden">Verificando...</span>
                                    </div>
                                    <p class="mt-2">Verificando requisitos do sistema...</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Etapa 2: Configuração do Banco -->
                        <div id="etapa-2" class="etapa d-none">
                            <h5><i class="bi bi-database"></i> 2. Configuração do Banco de Dados</h5>
                            <form id="form-database">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="host" class="form-label">Host</label>
                                            <input type="text" class="form-control" id="host" name="host" value="localhost" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="port" class="form-label">Porta</label>
                                            <input type="number" class="form-control" id="port" name="port" value="3306" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="database" class="form-label">Nome do Banco</label>
                                            <input type="text" class="form-control" id="database" name="database" value="ensalamento" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="username" class="form-label">Usuário</label>
                                            <input type="text" class="form-control" id="username" name="username" value="root" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Senha</label>
                                    <input type="password" class="form-control" id="password" name="password">
                                </div>
                                <button type="button" class="btn btn-primary" onclick="testarConexao()">
                                    <i class="bi bi-plug"></i> Testar Conexão
                                </button>
                            </form>
                            <div id="resultado-conexao" class="mt-3"></div>
                        </div>
                        
                        <!-- Etapa 3: Instalação -->
                        <div id="etapa-3" class="etapa d-none">
                            <h5><i class="bi bi-download"></i> 3. Instalação</h5>
                            <div id="progresso-instalacao">
                                <div class="text-center">
                                    <div class="spinner-border text-primary" role="status">
                                        <span class="visually-hidden">Instalando...</span>
                                    </div>
                                    <p class="mt-2">Criando tabelas e inserindo dados iniciais...</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Etapa 4: Finalização -->
                        <div id="etapa-4" class="etapa d-none">
                            <h5><i class="bi bi-check-circle-fill text-success"></i> 4. Instalação Concluída</h5>
                            <div class="alert alert-success">
                                <h6>Sistema instalado com sucesso!</h6>
                                <p class="mb-0">Você pode agora acessar o sistema com as credenciais:</p>
                                <ul class="mt-2 mb-0">
                                    <li><strong>Usuário:</strong> admin</li>
                                    <li><strong>Senha:</strong> admin123</li>
                                </ul>
                            </div>
                            <div class="text-center">
                                <a href="index.php" class="btn btn-success btn-lg">
                                    <i class="bi bi-house"></i> Acessar Sistema
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let etapaAtual = 1;
        
        // Iniciar instalação
        document.addEventListener('DOMContentLoaded', function() {
            verificarRequisitos();
        });
        
        function verificarRequisitos() {
            fetch('install.php?action=verificar_requisitos')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        exibirRequisitos(data.data);
                        if (data.data.todos_ok) {
                            setTimeout(() => avancarEtapa(2), 2000);
                        }
                    } else {
                        mostrarErro('Erro ao verificar requisitos: ' + data.message);
                    }
                })
                .catch(error => {
                    mostrarErro('Erro na comunicação: ' + error.message);
                });
        }
        
        function exibirRequisitos(data) {
            const lista = document.getElementById('requisitos-lista');
            let html = '<ul class="list-group">';
            
            const requisitos = {
                'php_version': 'PHP 7.4+ (' + data.php_version + ')',
                'pdo_mysql': 'PDO MySQL',
                'json': 'JSON',
                'mbstring': 'MBString',
                'writable': 'Diretório gravável'
            };
            
            for (const [key, nome] of Object.entries(requisitos)) {
                const status = data.requisitos[key];
                const classe = status ? 'list-group-item-success' : 'list-group-item-danger';
                const icone = status ? 'check-circle-fill' : 'x-circle-fill';
                
                html += `<li class="list-group-item ${classe}">
                    <i class="bi bi-${icone}"></i> ${nome}
                </li>`;
            }
            
            html += '</ul>';
            lista.innerHTML = html;
        }
        
        function testarConexao() {
            const form = document.getElementById('form-database');
            const formData = new FormData(form);
            formData.append('action', 'testar_conexao');
            
            const resultado = document.getElementById('resultado-conexao');
            resultado.innerHTML = '<div class="text-center"><div class="spinner-border text-primary" role="status"></div></div>';
            
            fetch('install.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    resultado.innerHTML = '<div class="alert alert-success"><i class="bi bi-check-circle"></i> ' + data.message + '</div>';
                    setTimeout(() => {
                        avancarEtapa(3);
                        executarInstalacao();
                    }, 1500);
                } else {
                    resultado.innerHTML = '<div class="alert alert-danger"><i class="bi bi-x-circle"></i> ' + data.message + '</div>';
                }
            })
            .catch(error => {
                resultado.innerHTML = '<div class="alert alert-danger">Erro na comunicação: ' + error.message + '</div>';
            });
        }
        
        function executarInstalacao() {
            fetch('install.php?action=instalar', { method: 'POST' })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('progresso-instalacao').innerHTML = 
                            '<div class="alert alert-success"><i class="bi bi-check-circle"></i> ' + data.message + '</div>';
                        setTimeout(() => {
                            avancarEtapa(4);
                            finalizarInstalacao();
                        }, 1500);
                    } else {
                        if (data.action_required === 'confirm_update') {
                            if (confirm(data.message)) {
                                // Continuar com atualização
                                fetch('install.php?action=instalar&force_update=1', { method: 'POST' })
                                    .then(response => response.json())
                                    .then(data => {
                                        if (data.success) {
                                            document.getElementById('progresso-instalacao').innerHTML = 
                                                '<div class="alert alert-success"><i class="bi bi-check-circle"></i> ' + data.message + '</div>';
                                            setTimeout(() => {
                                                avancarEtapa(4);
                                                finalizarInstalacao();
                                            }, 1500);
                                        } else {
                                            mostrarErro('Erro na instalação: ' + data.message);
                                        }
                                    });
                            }
                        } else {
                            mostrarErro('Erro na instalação: ' + data.message);
                        }
                    }
                })
                .catch(error => {
                    mostrarErro('Erro na comunicação: ' + error.message);
                });
        }
        
        function finalizarInstalacao() {
            fetch('install.php?action=finalizar', { method: 'POST' })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        atualizarProgresso(100);
                    }
                });
        }
        
        function avancarEtapa(novaEtapa) {
            document.getElementById('etapa-' + etapaAtual).classList.add('d-none');
            document.getElementById('etapa-' + novaEtapa).classList.remove('d-none');
            etapaAtual = novaEtapa;
            
            const progresso = (novaEtapa - 1) * 25;
            atualizarProgresso(progresso);
            
            const etapas = {
                1: 'Verificando requisitos...',
                2: 'Configurando banco de dados...',
                3: 'Instalando sistema...',
                4: 'Instalação concluída!'
            };
            
            document.getElementById('etapa-atual').textContent = etapas[novaEtapa];
        }
        
        function atualizarProgresso(porcentagem) {
            document.getElementById('progresso').style.width = porcentagem + '%';
        }
        
        function mostrarErro(mensagem) {
            document.getElementById('progresso-instalacao').innerHTML = 
                '<div class="alert alert-danger"><i class="bi bi-x-circle"></i> ' + mensagem + '</div>';
        }
    </script>
</body>
</html>
    <?php
}
?>

