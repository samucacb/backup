<?php
// Desabilitar TODOS os erros PHP para garantir JSON válido
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(0);

// Capturar qualquer erro e retornar JSON
set_error_handler(function($severity, $message, $file, $line) {
    return true;
});


/**
 * API Usuários
 * Gerencia operações CRUD de usuários
 */

// Suprimir erros PHP para garantir JSON válido
ini_set('display_errors', 0);
error_reporting(0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../config/database.php';

try {
    $action = $_GET['action'] ?? '';
    
    // Inicializar conexão com banco
    global $database;
    
    switch ($action) {
        case 'listar':
            listarUsuarios();
            break;
            
        case 'buscar':
            if (empty($_GET['id'])) {
                throw new Exception('ID do usuário é obrigatório');
            }
            buscarUsuario($_GET['id']);
            break;
            
        case 'criar':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Método não permitido');
            }
            criarUsuario();
            break;
            
        case 'atualizar':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Método não permitido');
            }
            atualizarUsuario();
            break;
            
        case 'excluir':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Método não permitido');
            }
            excluirUsuario();
            break;
            
        case 'alterar_senha':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Método não permitido');
            }
            alterarSenha();
            break;
            
        case 'perfil':
            obterPerfil();
            break;
            
        default:
            throw new Exception('Ação não reconhecida');
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

function listarUsuarios() {
    global $database;
    
    try {
        $stmt = $database->prepare("
            SELECT 
                id,
                username,
                nome,
                email,
                perfil,
                ativo,
                ultimo_login,
                created_at
            FROM usuarios 
            WHERE ativo = 1 
            ORDER BY nome
        ");
        
        $stmt->execute();
        $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'data' => $usuarios
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao listar usuários: ' . $e->getMessage()
        ]);
    }
}

function buscarUsuario($id) {
    global $database;
    
    try {
        $stmt = $database->prepare("
            SELECT 
                id,
                username,
                nome,
                email,
                perfil,
                ativo,
                ultimo_login,
                created_at
            FROM usuarios 
            WHERE id = ? AND ativo = 1
        ");
        
        $stmt->execute([$id]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$usuario) {
            throw new Exception('Usuário não encontrado');
        }
        
        echo json_encode([
            'success' => true,
            'data' => $usuario
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao buscar usuário: ' . $e->getMessage()
        ]);
    }
}

function criarUsuario() {
    global $database;
    
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            $input = $_POST;
        }
        
        // Validações
        if (empty($input['username'])) {
            throw new Exception('Nome de usuário é obrigatório');
        }
        
        if (empty($input['nome'])) {
            throw new Exception('Nome completo é obrigatório');
        }
        
        if (empty($input['email'])) {
            throw new Exception('E-mail é obrigatório');
        }
        
        if (empty($input['senha'])) {
            throw new Exception('Senha é obrigatória');
        }
        
        if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
            throw new Exception('E-mail inválido');
        }
        
        // Verificar se username já existe
        $stmt = $database->prepare("SELECT id FROM usuarios WHERE username = ? AND ativo = 1");
        $stmt->execute([$input['username']]);
        
        if ($stmt->fetch()) {
            throw new Exception('Nome de usuário já existe');
        }
        
        // Verificar se email já existe
        $stmt = $database->prepare("SELECT id FROM usuarios WHERE email = ? AND ativo = 1");
        $stmt->execute([$input['email']]);
        
        if ($stmt->fetch()) {
            throw new Exception('E-mail já cadastrado');
        }
        
        // Inserir usuário
        $stmt = $database->prepare("
            INSERT INTO usuarios (username, nome, email, senha, perfil, ativo) 
            VALUES (?, ?, ?, ?, ?, 1)
        ");
        
        $senha_hash = password_hash($input['senha'], PASSWORD_DEFAULT);
        $perfil = $input['perfil'] ?? 'usuario';
        
        $stmt->execute([
            $input['username'],
            $input['nome'],
            $input['email'],
            $senha_hash,
            $perfil
        ]);
        
        echo json_encode([
            'success' => true,
            'data' => [
                'id' => $database->lastInsertId(),
                'message' => 'Usuário criado com sucesso'
            ]
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao criar usuário: ' . $e->getMessage()
        ]);
    }
}

function atualizarUsuario() {
    global $database;
    
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            $input = $_POST;
        }
        
        if (empty($input['id'])) {
            throw new Exception('ID do usuário é obrigatório');
        }
        
        // Verificar se usuário existe
        $stmt = $database->prepare("SELECT id FROM usuarios WHERE id = ? AND ativo = 1");
        $stmt->execute([$input['id']]);
        
        if (!$stmt->fetch()) {
            throw new Exception('Usuário não encontrado');
        }
        
        // Verificar username duplicado (exceto o próprio usuário)
        if (!empty($input['username'])) {
            $stmt = $database->prepare("SELECT id FROM usuarios WHERE username = ? AND id != ? AND ativo = 1");
            $stmt->execute([$input['username'], $input['id']]);
            
            if ($stmt->fetch()) {
                throw new Exception('Nome de usuário já existe');
            }
        }
        
        // Verificar email duplicado (exceto o próprio usuário)
        if (!empty($input['email'])) {
            if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
                throw new Exception('E-mail inválido');
            }
            
            $stmt = $database->prepare("SELECT id FROM usuarios WHERE email = ? AND id != ? AND ativo = 1");
            $stmt->execute([$input['email'], $input['id']]);
            
            if ($stmt->fetch()) {
                throw new Exception('E-mail já cadastrado');
            }
        }
        
        // Atualizar usuário
        $stmt = $database->prepare("
            UPDATE usuarios SET 
                username = COALESCE(?, username),
                nome = COALESCE(?, nome),
                email = COALESCE(?, email),
                perfil = COALESCE(?, perfil),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        
        $stmt->execute([
            $input['username'] ?? null,
            $input['nome'] ?? null,
            $input['email'] ?? null,
            $input['perfil'] ?? null,
            $input['id']
        ]);
        
        echo json_encode([
            'success' => true,
            'data' => ['message' => 'Usuário atualizado com sucesso']
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao atualizar usuário: ' . $e->getMessage()
        ]);
    }
}

function excluirUsuario() {
    global $database;
    
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            $input = $_POST;
        }
        
        if (empty($input['id'])) {
            throw new Exception('ID do usuário é obrigatório');
        }
        
        // Verificar se usuário existe
        $stmt = $database->prepare("SELECT id FROM usuarios WHERE id = ? AND ativo = 1");
        $stmt->execute([$input['id']]);
        
        if (!$stmt->fetch()) {
            throw new Exception('Usuário não encontrado');
        }
        
        // Marcar como inativo (soft delete)
        $stmt = $database->prepare("UPDATE usuarios SET ativo = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$input['id']]);
        
        echo json_encode([
            'success' => true,
            'data' => ['message' => 'Usuário excluído com sucesso']
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao excluir usuário: ' . $e->getMessage()
        ]);
    }
}

function alterarSenha() {
    global $database;
    
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            $input = $_POST;
        }
        
        if (empty($input['id'])) {
            throw new Exception('ID do usuário é obrigatório');
        }
        
        if (empty($input['senha_atual'])) {
            throw new Exception('Senha atual é obrigatória');
        }
        
        if (empty($input['senha_nova'])) {
            throw new Exception('Nova senha é obrigatória');
        }
        
        // Buscar usuário
        $stmt = $database->prepare("SELECT id, senha FROM usuarios WHERE id = ? AND ativo = 1");
        $stmt->execute([$input['id']]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$usuario) {
            throw new Exception('Usuário não encontrado');
        }
        
        // Verificar senha atual
        if (!password_verify($input['senha_atual'], $usuario['senha'])) {
            throw new Exception('Senha atual incorreta');
        }
        
        // Atualizar senha
        $stmt = $database->prepare("UPDATE usuarios SET senha = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $nova_senha_hash = password_hash($input['senha_nova'], PASSWORD_DEFAULT);
        $stmt->execute([$nova_senha_hash, $input['id']]);
        
        echo json_encode([
            'success' => true,
            'data' => ['message' => 'Senha alterada com sucesso']
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao alterar senha: ' . $e->getMessage()
        ]);
    }
}

function obterPerfil() {
    try {
        // Simular usuário logado
        $perfil = [
            'id' => 1,
            'username' => 'admin',
            'nome' => 'Administrador',
            'email' => 'admin@sistema.com',
            'perfil' => 'admin',
            'ultimo_login' => date('Y-m-d H:i:s', strtotime('-2 hours')),
            'permissoes' => [
                'salas' => ['criar', 'editar', 'excluir', 'visualizar'],
                'turmas' => ['criar', 'editar', 'excluir', 'visualizar'],
                'ensalamento' => ['executar', 'visualizar', 'exportar'],
                'usuarios' => ['criar', 'editar', 'excluir', 'visualizar'],
                'configuracoes' => ['editar', 'visualizar']
            ]
        ];
        
        echo json_encode([
            'success' => true,
            'data' => $perfil
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Erro ao obter perfil: ' . $e->getMessage()
        ]);
    }
}
?>

