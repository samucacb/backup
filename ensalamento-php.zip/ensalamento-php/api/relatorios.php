<?php
// ====================================================================
// >> MODO DE DEPURAÇÃO FORÇADA <<
// Estas linhas irão forçar a exibição de TODOS os erros, incluindo os fatais.
// ====================================================================
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ====================================================================

// O resto do seu código continua aqui...
require_once __DIR__ . '/../vendor/autoload.php'; 

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Remova ou comente os outros error_reporting e set_error_handler que você tinha,
// para que não interfiram com a depuração forçada.

// header('Content-Type: application/json'); // Comente isso por enquanto
// ...

require_once __DIR__ . '/../config/database.php';

// ... e o resto do seu arquivo ...


try {
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'cursos':
            $response = obterCursos($database);
            break;
            
        case 'metricas':
            $response = obterMetricas($database);
            break;

        case 'kpis_adicionais':
            $response = _obterDadosKpisAdicionais($database, $_GET['periodo'] ?? '');
            break;
            
        case 'grafico_status':
            $response = obterDadosGraficoStatus($database);
            break;
            
        case 'grafico_ocupacao_horario':
            $response = obterDadosGraficoOcupacaoHorario($database);
            break;
            
        case 'grafico_eficiencia_sala':
            $response = obterDadosGraficoEficienciaSala($database);
            break;

        case 'grafico_eficiencia_sala':
            $response = obterDadosGraficoEficienciaSala($database);
            break;
            
        case 'tabela_detalhada':
            $response = obterTabelaDetalhada($database);
            break;
            
        case 'exportar':
            $response = exportarRelatorio($database);
            break;

        case 'grafico_ocupacao_dia':
            $response = _obterDadosGraficoOcupacaoDiaParaExportacao($database, $_GET['periodo'] ?? '');
            break;

        case 'exportar_ensalamento':
            exportarRelatorioEnsalamento($database);
            break;

        case 'status':
            $response = obterStatus($database);
            break;
            
        case 'historico':
            $response = obterHistorico($database);
            break;

        case 'analise_conflitos':
            $response = obterAnaliseDeConflitos($database);
            break;
            
        default:
            throw new Exception('Ação não reconhecida');
    }
    
    echo json_encode([
        'success' => true,
        'data' => $response
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

// Em api/relatorios.php
// >> SUBSTITUA a sua função obterMetricas por esta <<

function obterMetricas($database) {
    if (empty($_GET['periodo'])) {
        http_response_code(400 );
        echo json_encode(['success' => false, 'message' => 'O parâmetro "periodo" é obrigatório.']);
        exit;
    }
    $periodo = $_GET['periodo'];

    // 1. Obter o total de turmas do período
    $stmt_total_turmas = $database->prepare("SELECT COUNT(id) FROM turmas WHERE periodo = ? AND ativo = 1");
    $stmt_total_turmas->execute([$periodo]);
    $total_turmas_periodo = $stmt_total_turmas->fetchColumn() ?? 0;

    // 2. Obter métricas das turmas ALOCADAS
    $stmt_metricas = $database->prepare("
        SELECT 
            COUNT(DISTINCT turma_id) as total_alocadas,
            COUNT(DISTINCT sala_id) as total_salas_utilizadas,
            AVG(eficiencia) as media_eficiencia
        FROM ensalamento
        WHERE periodo = ? AND status = 'alocado'
    ");
    $stmt_metricas->execute([$periodo]);
    $metricas_alocadas = $stmt_metricas->fetch(PDO::FETCH_ASSOC);

    $turmas_alocadas = (int)($metricas_alocadas['total_alocadas'] ?? 0);
    $salas_utilizadas = (int)($metricas_alocadas['total_salas_utilizadas'] ?? 0);
    $eficiencia_media = (float)($metricas_alocadas['media_eficiencia'] ?? 0);

    // 3. Calcular a taxa de alocação
    $taxa_alocacao = ($total_turmas_periodo > 0) ? round(($turmas_alocadas / $total_turmas_periodo) * 100, 1) : 0;

    // 4. Montar a resposta final
    $response = [
        'total_ensalamentos' => $turmas_alocadas,
        'taxa_alocacao' => $taxa_alocacao,
        'eficiencia_ocupacao' => $eficiencia_media,
        'salas_utilizadas' => $salas_utilizadas
    ];
    
    // Esta função deve retornar os dados, não imprimir. O switch case fará o echo.
    return $response; 
}

// Em api/relatorios.php
// >> SUBSTITUA a sua função _obterDadosKpisAdicionais por esta versão completa <<

function _obterDadosKpisAdicionais($database, $periodo) {
    if (empty($periodo)) {
        return [
            'total_salas' => 0, 'total_turmas' => 0, 
            'total_alocacoes' => 0, 'media_alocacoes_dia' => 0
        ];
    }

    // 1. Total de Salas Ativas
    $stmt_salas = $database->query("SELECT COUNT(id) FROM salas WHERE ativo = 1");
    $total_salas = $stmt_salas->fetchColumn() ?? 0;

    // 2. Total de Turmas Ativas no Período
    $stmt_turmas = $database->prepare("SELECT COUNT(id) FROM turmas WHERE periodo = ? AND ativo = 1");
    $stmt_turmas->execute([$periodo]);
    $total_turmas = $stmt_turmas->fetchColumn() ?? 0;

    // 3. Total de Alocações
    $stmt_alocacoes = $database->prepare("
        SELECT COUNT(id) as total_alocacoes
        FROM ensalamento
        WHERE periodo = ? AND status = 'alocado'
    ");
    $stmt_alocacoes->execute([$periodo]);
    $total_alocacoes = $stmt_alocacoes->fetchColumn() ?? 0;
    
    // 4. Média de Alocações por Dia (reintroduzida)
    $media_alocacoes_dia = ($total_alocacoes > 0) ? round($total_alocacoes / 6, 1) : 0;

    return [
        'total_salas' => (int)$total_salas,
        'total_turmas' => (int)$total_turmas,
        'total_alocacoes' => (int)$total_alocacoes,       // << NOVO
        'media_alocacoes_dia' => (float)$media_alocacoes_dia // << MANTIDO
    ];
}


function obterDadosGraficoStatus($database) {
    if (empty($_GET['periodo'])) {
        http_response_code(400 );
        echo json_encode(['success' => false, 'message' => 'O parâmetro "periodo" é obrigatório.']);
        exit;
    }
    $periodo = $_GET['periodo'];
    
    // A mesma consulta corrigida da função "pura"
    $sql = "
        SELECT 
            COALESCE(ens.status, 'pendente') AS status_final, 
            COUNT(tur.id) AS quantidade
        FROM 
            turmas AS tur
        LEFT JOIN 
            (SELECT turma_id, MAX(status) as status FROM ensalamento WHERE periodo = ? GROUP BY turma_id) AS ens 
            ON tur.id = ens.turma_id
        WHERE 
            tur.periodo = ?
        GROUP BY 
            status_final
    ";
    
    $stmt = $database->prepare($sql);
    $stmt->execute([$periodo, $periodo]);
    $resultados = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    $dados = [
        'alocadas' => (int)($resultados['alocado'] ?? 0),
        'conflitos' => (int)($resultados['conflito'] ?? 0),
        'pendentes' => (int)($resultados['pendente'] ?? 0)
    ];

    // A sua função original retorna um JSON, então mantemos isso.
    return $dados;
}




// Em api/relatorios.php
function obterDadosGraficoOcupacaoHorario($database) {
    if (empty($_GET['periodo'])) {
    // Se o período não for fornecido, encerra a execução com um erro claro.
    http_response_code(400 ); // 400 = Bad Request
    echo json_encode(['success' => false, 'message' => 'O parâmetro "periodo" é obrigatório.']);
    exit; // Interrompe o script
}
$periodo = $_GET['periodo'];
    
    $sql = "SELECT 
                HOUR(horario_inicio) as hora, 
                COUNT(id) as quantidade
            FROM ensalamento
            WHERE periodo = ? AND status = 'alocado' AND horario_inicio IS NOT NULL -- <-- CORRIGIDO AQUI
            GROUP BY hora
            ORDER BY hora ASC";
    
    $stmt = $database->prepare($sql);
    $stmt->execute([$periodo]);
    // ... resto da função ...
    $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $labels = [];
    $valores = [];
    foreach ($dados as $item) {
        $labels[] = str_pad($item['hora'], 2, '0', STR_PAD_LEFT) . ':00';
        $valores[] = (int)$item['quantidade'];
    }
    
    return ['labels' => $labels, 'data' => $valores];
}

function obterCursos($database) {
    try {
        // A consulta busca todos os cursos distintos, ignora valores nulos ou vazios, e ordena em ordem alfabética.
        $sql = "SELECT DISTINCT curso FROM turmas WHERE curso IS NOT NULL AND curso != '' ORDER BY curso ASC";
        
        $stmt = $database->prepare($sql);
        $stmt->execute();
        
        // Retorna apenas uma lista simples de strings, ex: ["Direito", "Engenharia", "Medicina"]
        return $stmt->fetchAll(PDO::FETCH_COLUMN, 0);

    } catch (Exception $e) {
        // Se houver um erro de banco de dados, lança uma exceção para ser capturada pelo bloco principal.
        throw new Exception('Erro ao buscar a lista de cursos: ' . $e->getMessage());
    }
}


function obterDadosGraficoEficienciaSala($database) {
    if (empty($_GET['periodo'])) {
        http_response_code(400 );
        echo json_encode(['success' => false, 'message' => 'O parâmetro "periodo" é obrigatório.']);
        exit;
    }
    $periodo = $_GET['periodo'];

    $sql = "
        SELECT 
            s.nome as nome_sala,
            AVG(e.eficiencia) as eficiencia_media
        FROM ensalamento e
        JOIN salas s ON e.sala_id = s.id
        WHERE e.periodo = ? AND e.status = 'alocado'
        GROUP BY s.id, s.nome
        ORDER BY eficiencia_media DESC
        LIMIT 10; -- Limita às 10 salas para um gráfico mais limpo
    ";
    $stmt = $database->prepare($sql);
    $stmt->execute([$periodo]);
    $resultados = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    // Formata os dados para o Chart.js (labels e data)
    $response = [
        'labels' => array_keys($resultados),
        'data' => array_values($resultados)
    ];

    return $response;
}


function obterTabelaDetalhada($database) {
    // Sua validação de período (correta e original)
    if (empty($_GET['periodo'])) {
        http_response_code(400 );
        echo json_encode(['success' => false, 'message' => 'O parâmetro "periodo" é obrigatório.']);
        exit;
    }
    $periodo = $_GET['periodo'];
    $filtro_status = $_GET['status'] ?? '';
    $filtro_curso = $_GET['curso'] ?? '';

    // Sua definição de colunas (correta e original)
    $colunas = [
        ['campo' => 'turma_codigo', 'titulo' => 'Turma'], ['campo' => 'turma_nome', 'titulo' => 'Disciplina'],
        ['campo' => 'professor', 'titulo' => 'Professor'], ['campo' => 'turno', 'titulo' => 'Turno'],
        ['campo' => 'dias_da_semana', 'titulo' => 'Dias'], ['campo' => 'horario', 'titulo' => 'Horário'],
        ['campo' => 'sala_alocada', 'titulo' => 'Sala Alocada'], ['campo' => 'status_final', 'titulo' => 'Status', 'tipo' => 'status'],
        ['campo' => 'detalhes_conflito', 'titulo' => 'Detalhes do Conflito']
    ];

    // Sua consulta principal (corrigida apenas com num_alunos)
    $sql_todas_as_turmas = "
        SELECT 
            t.id, t.codigo, t.nome, t.professor, t.turno, t.num_alunos, t.curso,
            t.horario_inicio, t.horario_fim,
            t.segunda, t.terca, t.quarta, t.quinta, t.sexta, t.sabado,
            t.sala_fixa_id, s.codigo as sala_fixa_codigo
        FROM turmas t
        LEFT JOIN salas s ON t.sala_fixa_id = s.id
        WHERE t.periodo = ?
    ";
    $stmt_turmas = $database->prepare($sql_todas_as_turmas);
    $stmt_turmas->execute([$periodo]);
    $todas_as_turmas = $stmt_turmas->fetchAll(PDO::FETCH_ASSOC);

    // Sua lógica de detecção de conflitos (correta e original)
    $conflitos_mapeados = [];
    for ($i = 0; $i < count($todas_as_turmas); $i++) {
        for ($j = $i + 1; $j < count($todas_as_turmas); $j++) {
            $t1 = $todas_as_turmas[$i]; $t2 = $todas_as_turmas[$j];
            $horario_colide = ($t1['horario_inicio'] < $t2['horario_fim']) && ($t1['horario_fim'] > $t2['horario_inicio']);
            if ($horario_colide) {
                $dias_conflitantes = [];
                $dias_semana = ['segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado'];
                foreach ($dias_semana as $dia) {
                    if ($t1[$dia] && $t2[$dia]) $dias_conflitantes[] = ucfirst($dia);
                }
                if (!empty($dias_conflitantes)) {
                    $motivo = '';
                    if ($t1['sala_fixa_id'] && $t1['sala_fixa_id'] === $t2['sala_fixa_id']) {
                        $motivo = "Sala Fixa " . $t1['sala_fixa_codigo'];
                    } elseif ($t1['professor'] === $t2['professor']) {
                        $motivo = "Professor(a) " . $t1['professor'];
                    }
                    if ($motivo) {
                        $mensagem = sprintf("Conflito com Turma %s por %s nos dias: %s", $t2['codigo'], $motivo, implode(', ', $dias_conflitantes));
                        $conflitos_mapeados[$t1['id']][] = $mensagem;
                        $mensagem_reversa = sprintf("Conflito com Turma %s por %s nos dias: %s", $t1['codigo'], $motivo, implode(', ', $dias_conflitantes));
                        $conflitos_mapeados[$t2['id']][] = $mensagem_reversa;
                    }
                }
            }
        }
    }

    // Sua lógica de construção de linhas (correta e original)
    $linhas = [];
    foreach ($todas_as_turmas as $turma) {
        $sql_ensalamentos = "
            SELECT e.dia_semana, e.status, s.codigo as sala_codigo, s.capacidade as sala_capacidade
            FROM ensalamento e LEFT JOIN salas s ON e.sala_id = s.id
            WHERE e.turma_id = ? AND e.periodo = ?
        ";
        $stmt_ensalamentos = $database->prepare($sql_ensalamentos);
        $stmt_ensalamentos->execute([$turma['id'], $periodo]);
        $ensalamentos = $stmt_ensalamentos->fetchAll(PDO::FETCH_ASSOC);

        $salas_alocadas = []; $status_final = 'Pendente'; $capacidade_sala = null;
        
        if (!empty($ensalamentos)) {
            $status_temp = 'alocado';
            foreach ($ensalamentos as $e) {
                $dias_turma[] = ucfirst($e['dia_semana']);
                $salas_alocadas[] = $e['sala_codigo'] ?? 'N/A';
                if ($e['status'] === 'conflito') $status_temp = 'conflito';
                if (isset($e['sala_capacidade'])) $capacidade_sala = (int)$e['sala_capacidade'];
            }
            $status_final = $status_temp;
        }

        $detalhes = $conflitos_mapeados[$turma['id']] ?? [];

                $dias_turma = [];
        $mapa_dias = ['segunda' => 'Segunda', 'terca' => 'Terça', 'quarta' => 'Quarta', 'quinta' => 'Quinta', 'sexta' => 'Sexta', 'sabado' => 'Sábado'];
        foreach ($mapa_dias as $coluna_dia => $nome_dia) {
            if (!empty($turma[$coluna_dia])) { // Verifica se a coluna do dia (ex: 'segunda') está marcada como 1 (true)
                $dias_turma[] = $nome_dia;
            }
        }

        if ($status_final === 'conflito' && empty($detalhes)) {
            $detalhes[] = 'Alocação incompleta (provavelmente sem sala designada).';
        }

        if ($status_final === 'alocado' && $capacidade_sala !== null && (int)$turma['num_alunos'] > $capacidade_sala) {
            // Adiciona a mensagem de superlotação no início do array de detalhes.
            // NÃO altera o $status_final.
            array_unshift($detalhes, sprintf(
                "Superlotação: Turma com %d alunos em sala com capacidade para %d.",
                $turma['num_alunos'], $capacidade_sala
            ));
        }
        // =================================================================
        if (!empty($filtro_curso) && $turma['curso'] !== $filtro_curso) {
            continue;
        }
        if (!empty($filtro_status) && strtolower($status_final) !== strtolower($filtro_status)) {
            continue;
        }
        $linhas[] = [
            'turma_codigo' => $turma['codigo'], 'turma_nome' => $turma['nome'],
            'professor' => $turma['professor'], 'turno' => $turma['turno'],
            'dias_da_semana' => !empty($dias_turma) ? implode(', ', array_unique($dias_turma)) : 'N/A',
            'horario' => substr($turma['horario_inicio'], 0, 5) . ' - ' . substr($turma['horario_fim'], 0, 5),
            'sala_alocada' => !empty($salas_alocadas) ? implode(', ', array_unique($salas_alocadas)) : 'N/A',
            'status_final' => $status_final, // Usa o status original ('alocado', 'conflito', 'pendente')
            'detalhes_conflito' => implode('; ', $detalhes) // Adiciona a mensagem de superlotação aqui
        ];
    }

    return ['colunas' => $colunas, 'linhas' => $linhas];
}


function _obterMetricasParaExportacao($database, $periodo) {
    // 1. Encontrar a data/hora exata da última inserção no período
    $stmt_ultima_data = $database->prepare("SELECT MAX(created_at) FROM ensalamento WHERE periodo = ?");
    $stmt_ultima_data->execute([$periodo]);
    $ultima_data_execucao = $stmt_ultima_data->fetchColumn();

    $turmas_alocadas = 0;
    $salas_utilizadas = 0;
    $eficiencia_media_correta = 0;

    // 2. Se encontramos uma data, calculamos as métricas para ela
    if ($ultima_data_execucao) {
        $stmt_metricas = $database->prepare("
            SELECT 
                COUNT(DISTINCT e.turma_id) as total_alocadas,
                COUNT(DISTINCT e.sala_id) as total_salas,
                AVG(t.num_alunos / s.capacidade) * 100 as media_eficiencia
            FROM ensalamento e
            JOIN turmas t ON e.turma_id = t.id
            JOIN salas s ON e.sala_id = s.id
            WHERE e.created_at = ? AND e.status = 'alocado' AND s.capacidade > 0
        ");
        $stmt_metricas->execute([$ultima_data_execucao]);
        $resultado_metricas = $stmt_metricas->fetch(PDO::FETCH_ASSOC);

        $turmas_alocadas = $resultado_metricas['total_alocadas'] ?? 0;
        $salas_utilizadas = $resultado_metricas['total_salas'] ?? 0;
        $eficiencia_media_correta = $resultado_metricas['media_eficiencia'] ?? 0;
    }
    
    // 3. Calcular a taxa de alocação
    $stmt_total_turmas = $database->prepare("SELECT COUNT(id) as total FROM turmas WHERE periodo = ? AND ativo = 1");
    $stmt_total_turmas->execute([$periodo]);
    $total_turmas_periodo = $stmt_total_turmas->fetchColumn() ?? 0;
    $taxa_alocacao = ($total_turmas_periodo > 0) ? ($turmas_alocadas / $total_turmas_periodo) * 100 : 0;

    // 4. Retornar os dados formatados
    return [
        'total_ensalamentos' => (int)$turmas_alocadas,
        'taxa_alocacao' => (float)$taxa_alocacao,
        'eficiencia_ocupacao' => (float)$eficiencia_media_correta,
        'salas_utilizadas' => (int)$salas_utilizadas
    ];
}


function _obterDadosGraficoStatusParaExportacao($database, $periodo) {
    // ====================================================================
    // >> CONSULTA CORRIGIDA AQUI <<
    // Esta consulta agora olha para TODAS as turmas e determina seu status,
    // garantindo que as pendentes sejam contadas.
    // ====================================================================
    $sql = "
        SELECT 
            -- Define o status de cada turma: se tem ensalamento, usa o status de lá, senão, é 'pendente'.
            COALESCE(ens.status, 'pendente') AS status_final, 
            COUNT(tur.id) AS quantidade
        FROM 
            turmas AS tur
        LEFT JOIN 
            -- Usamos uma subconsulta para pegar o status mais 'grave' de cada turma no ensalamento.
            -- (Ex: se uma turma tem 4 alocações e 1 conflito, seu status geral é 'conflito').
            (SELECT turma_id, MAX(status) as status FROM ensalamento WHERE periodo = ? GROUP BY turma_id) AS ens 
            ON tur.id = ens.turma_id
        WHERE 
            tur.periodo = ?
        GROUP BY 
            status_final
    ";

    $stmt = $database->prepare($sql);
    // Note que o período é usado duas vezes na consulta, então precisa ser passado duas vezes.
    $stmt->execute([$periodo, $periodo]); 
    $resultados = $stmt->fetchAll(PDO::FETCH_KEY_PAIR); // Pega os resultados como ['status' => quantidade]

    // Garante que todos os status existam na resposta, mesmo que com valor 0.
    return [
        'alocadas' => (int)($resultados['alocado'] ?? 0),
        'conflitos' => (int)($resultados['conflito'] ?? 0),
        'pendentes' => (int)($resultados['pendente'] ?? 0)
    ];
}


function _obterDadosGraficoEficienciaSalaParaExportacao($database, $periodo) {
    $sql = "
        SELECT 
            s.nome as nome_sala,
            AVG(e.eficiencia) as eficiencia_media
        FROM ensalamento e
        JOIN salas s ON e.sala_id = s.id
        WHERE e.periodo = ? AND e.status = 'alocado'
        GROUP BY s.id, s.nome
        ORDER BY eficiencia_media DESC
        LIMIT 10; -- Limita às 10 salas mais eficientes para um gráfico mais limpo
    ";
    $stmt = $database->prepare($sql);
    $stmt->execute([$periodo]);
    // Retorna um array no formato ['Sala A101' => 95.5, 'Laboratório 202' => 88.0]
    return $stmt->fetchAll(PDO::FETCH_KEY_PAIR); 
}

/**
 * Obtém os dados para os indicadores de performance (que já temos na função de métricas).
 * Esta função apenas reutiliza a outra para manter a consistência.
 */
function _obterDadosIndicadoresPerformanceParaExportacao($database, $periodo) {
    // Reutiliza a função de métricas, pois ela já contém todos os dados necessários.
    return _obterMetricasParaExportacao($database, $periodo);
}


function _obterDadosGraficoOcupacaoParaExportacao($database, $periodo) {
    // Esta consulta conta quantas aulas alocadas (sem conflito) existem em cada horário de início.
    $sql = "
        SELECT 
            TIME_FORMAT(horario_inicio, '%H:%i') as horario, 
            COUNT(id) as quantidade
        FROM 
            ensalamento
        WHERE 
            periodo = ? AND status = 'alocado'
        GROUP BY 
            horario
        ORDER BY 
            horario ASC
    ";
    $stmt = $database->prepare($sql);
    $stmt->execute([$periodo]);
    
    // Retorna os dados no formato ['horario' => quantidade]
    return $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
}

function _obterDadosKpisAdicionaisParaExportacao($database, $periodo) {
    if (empty($periodo)) {
        return ['total_salas' => 0, 'total_turmas' => 0, 'total_alocacoes' => 0, 'media_alocacoes_dia' => 0];
    }
    $stmt_salas = $database->query("SELECT COUNT(id) FROM salas WHERE ativo = 1");
    $total_salas = $stmt_salas->fetchColumn() ?? 0;
    $stmt_turmas = $database->prepare("SELECT COUNT(id) FROM turmas WHERE periodo = ? AND ativo = 1");
    $stmt_turmas->execute([$periodo]);
    $total_turmas = $stmt_turmas->fetchColumn() ?? 0;
    $stmt_alocacoes = $database->prepare("SELECT COUNT(id) FROM ensalamento WHERE periodo = ? AND status = 'alocado'");
    $stmt_alocacoes->execute([$periodo]);
    $total_alocacoes = $stmt_alocacoes->fetchColumn() ?? 0;
    $media_alocacoes_dia = ($total_alocacoes > 0) ? round($total_alocacoes / 6, 1) : 0;
    return [
        'total_salas' => (int)$total_salas,
        'total_turmas' => (int)$total_turmas,
        'total_alocacoes' => (int)$total_alocacoes,
        'media_alocacoes_dia' => (float)$media_alocacoes_dia
    ];
}

// Em api/relatorios.php
// >> ADICIONE esta nova função ao final do arquivo, junto com as outras funções "puras" <<

function _obterDadosGraficoOcupacaoDiaParaExportacao($database, $periodo) {
    if (empty($periodo)) { return []; }

    $sql = "
        SELECT 
            dia_semana, 
            COUNT(id) as quantidade
        FROM ensalamento
        WHERE periodo = ? AND status = 'alocado'
        GROUP BY dia_semana
    ";
    $stmt = $database->prepare($sql);
    $stmt->execute([$periodo]);
    $resultados = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    // Garante que todos os dias da semana estejam presentes e na ordem correta
    $dias_ordenados = [
        'Segunda' => 0, 'Terca' => 0, 'Quarta' => 0, 
        'Quinta' => 0, 'Sexta' => 0, 'Sabado' => 0
    ];

    foreach ($resultados as $dia => $quantidade) {
        // Capitaliza a primeira letra para corresponder às chaves do array ordenado
        $dia_formatado = ucfirst(strtolower($dia));
        if (array_key_exists($dia_formatado, $dias_ordenados)) {
            $dias_ordenados[$dia_formatado] = (int)$quantidade;
        }
    }
    
    // Retorna um array no formato que o Chart.js espera (labels e data)
    return [
        'labels' => array_keys($dias_ordenados),
        'data' => array_values($dias_ordenados)
    ];
}


// Em api/relatorios.php
// >> SUBSTITUA TODA A SUA FUNÇÃO exportarRelatorioEnsalamento PELA VERSÃO ABAIXO <<

function exportarRelatorioEnsalamento($database) {
    if (ob_get_level() > 0) { ob_end_clean(); }

    try {
        // --- OBTENÇÃO DE DADOS ---
        $periodo_ativo = $database->query("SELECT MAX(periodo) as ultimo_periodo FROM turmas")->fetchColumn();
        if (!$periodo_ativo) { throw new Exception("Nenhum período ativo encontrado."); }
        
        $_GET['periodo'] = $periodo_ativo;
        $dados_detalhados = obterTabelaDetalhada($database);
        $mapa_conflitos = [];
        if (isset($dados_detalhados['linhas']) && is_array($dados_detalhados['linhas'])) {
            foreach ($dados_detalhados['linhas'] as $linha) {
                if (!empty($linha['detalhes_conflito'])) {
                    $mapa_conflitos[$linha['turma_codigo']] = $linha['detalhes_conflito'];
                }
            }
        }
        
        $dados_grafico_status = _obterDadosGraficoStatusParaExportacao($database, $periodo_ativo);
        $dados_metricas = _obterMetricasParaExportacao($database, $periodo_ativo);
        $dados_grafico_ocupacao_horario = _obterDadosGraficoOcupacaoParaExportacao($database, $periodo_ativo);
        $dados_grafico_eficiencia = _obterDadosGraficoEficienciaSalaParaExportacao($database, $periodo_ativo);
        $dados_indicadores = _obterDadosIndicadoresPerformanceParaExportacao($database, $periodo_ativo);

        // =================================================================
        // >> ADIÇÃO 1: Chamar as novas funções para obter os novos dados <<
        // =================================================================
        $dados_kpis_adicionais = _obterDadosKpisAdicionaisParaExportacao($database, $periodo_ativo);
        $dados_grafico_ocupacao_dia = _obterDadosGraficoOcupacaoDiaParaExportacao($database, $periodo_ativo);
        // =================================================================

        // --- CONFIGURAÇÃO DA PLANILHA ---
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet_relatorio = $spreadsheet->getActiveSheet();
        $sheet_relatorio->setTitle('Relatório Detalhado');
        $sheet_dashboard = $spreadsheet->createSheet();
        $sheet_dashboard->setTitle('Dashboard Gráfico');
        $sheet_dados_graficos = $spreadsheet->createSheet();
        $sheet_dados_graficos->setTitle('Dados dos Gráficos');

        // --- PREENCHER ABA "RELATÓRIO DETALHADO" ---
        // (Seu código existente e funcional, sem alterações)
        $headers = [
            'A1' => 'Status Alocação', 'B1' => 'Curso', 'C1' => 'Período', 'D1' => 'Código da Turma', 
            'E1' => 'Nome da Disciplina', 'F1' => 'Professor', 'G1' => 'Nº de Alunos', 'H1' => 'Código da Sala', 
            'I1' => 'Nome da Sala', 'J1' => 'Capacidade da Sala', 'K1' => 'Dia da Semana', 'L1' => 'Horário Início', 
            'M1' => 'Horário Fim', 'N1' => 'Detalhes do Conflito'
        ];
        foreach ($headers as $cell => $value) { $sheet_relatorio->setCellValue($cell, $value); }
        $sheet_relatorio->getStyle('A1:N1')->getFont()->setBold(true);
        $sql = "
            SELECT 
                tur.curso, tur.periodo, tur.codigo AS codigo_turma, tur.nome AS nome_disciplina,
                tur.professor, tur.num_alunos, sal.codigo AS codigo_sala, sal.nome AS nome_sala,
                sal.capacidade, ens.dia_semana, ens.horario_inicio, ens.horario_fim,
                (CASE WHEN ens.id IS NOT NULL THEN 'Alocado' ELSE 'Pendente' END) AS status_alocacao
            FROM turmas AS tur
            LEFT JOIN ensalamento AS ens ON tur.id = ens.turma_id
            LEFT JOIN salas AS sal ON ens.sala_id = sal.id
            WHERE tur.ativo = 1 AND tur.periodo = ?
            ORDER BY status_alocacao DESC, tur.curso, tur.nome
        ";
        $stmt = $database->prepare($sql);
        $stmt->execute([$periodo_ativo]);
        $row = 2;
        while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $detalhes_conflito = $mapa_conflitos[$data['codigo_turma']] ?? '';
            $sheet_relatorio->setCellValue('A' . $row, $data['status_alocacao']);
            $sheet_relatorio->setCellValue('B' . $row, $data['curso']);
            $sheet_relatorio->setCellValueExplicit('C' . $row, $data['periodo'], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            $sheet_relatorio->setCellValue('D' . $row, $data['codigo_turma']);
            $sheet_relatorio->setCellValue('E' . $row, $data['nome_disciplina']);
            $sheet_relatorio->setCellValue('F' . $row, $data['professor']);
            $sheet_relatorio->setCellValue('G' . $row, $data['num_alunos']);
            $sheet_relatorio->setCellValue('H' . $row, $data['codigo_sala']);
            $sheet_relatorio->setCellValue('I' . $row, $data['nome_sala']);
            $sheet_relatorio->setCellValue('J' . $row, $data['capacidade']);
            $sheet_relatorio->setCellValue('K' . $row, $data['dia_semana']);
            $sheet_relatorio->setCellValue('L' . $row, $data['horario_inicio']);
            $sheet_relatorio->setCellValue('M' . $row, $data['horario_fim']);
            $sheet_relatorio->setCellValue('N' . $row, $detalhes_conflito);
            $row++;
        }
        foreach (range('A', 'N') as $columnID) { $sheet_relatorio->getColumnDimension($columnID)->setAutoSize(true); }

        // --- PREENCHER ABA "DASHBOARD GRÁFICO" ---
        
        // KPIs Principais (Linha 1)
        if ($dados_metricas && is_array($dados_metricas)) {
            $style_titulo = ['font' => ['bold' => true, 'size' => 10, 'color' => ['rgb' => '6c757d']], 'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER]];
            $style_valor = ['font' => ['bold' => true, 'size' => 20, 'color' => ['rgb' => '0d6efd']], 'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER]];
            $sheet_dashboard->mergeCells('B2:D2'); $sheet_dashboard->getStyle('B2')->applyFromArray($style_titulo);
            $sheet_dashboard->setCellValue('B2', 'Total de Ensalamentos');
            $sheet_dashboard->mergeCells('B3:D3'); $sheet_dashboard->getStyle('B3')->applyFromArray($style_valor);
            $sheet_dashboard->setCellValue('B3', $dados_metricas['total_ensalamentos']);
            $sheet_dashboard->mergeCells('F2:H2'); $sheet_dashboard->getStyle('F2')->applyFromArray($style_titulo);
            $sheet_dashboard->setCellValue('F2', 'Taxa de Alocação');
            $sheet_dashboard->mergeCells('F3:H3'); $sheet_dashboard->getStyle('F3')->applyFromArray($style_valor);
            $sheet_dashboard->setCellValue('F3', $dados_metricas['taxa_alocacao'] / 100);
            $sheet_dashboard->getStyle('F3')->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_PERCENTAGE_0);
            $sheet_dashboard->mergeCells('J2:L2'); $sheet_dashboard->getStyle('J2')->applyFromArray($style_titulo);
            $sheet_dashboard->setCellValue('J2', 'Eficiência de Ocupação');
            $sheet_dashboard->mergeCells('J3:L3'); $sheet_dashboard->getStyle('J3')->applyFromArray($style_valor);
            $sheet_dashboard->setCellValue('J3', $dados_metricas['eficiencia_ocupacao'] / 100);
            $sheet_dashboard->getStyle('J3')->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_PERCENTAGE_0);
            $sheet_dashboard->mergeCells('N2:P2'); $sheet_dashboard->getStyle('N2')->applyFromArray($style_titulo);
            $sheet_dashboard->setCellValue('N2', 'Salas Utilizadas');
            $sheet_dashboard->mergeCells('N3:P3'); $sheet_dashboard->getStyle('N3')->applyFromArray($style_valor);
            $sheet_dashboard->setCellValue('N3', $dados_metricas['salas_utilizadas']);
        }

        // =================================================================
        // >> ADIÇÃO 2: Adicionar os novos KPIs na linha abaixo <<
        // =================================================================
        if ($dados_kpis_adicionais && is_array($dados_kpis_adicionais)) {
            $style_titulo_2 = ['font' => ['bold' => true, 'size' => 10, 'color' => ['rgb' => '6c757d']], 'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER]];
            $style_valor_2 = ['font' => ['bold' => true, 'size' => 20, 'color' => ['rgb' => '0d6efd']], 'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER]];
            $sheet_dashboard->mergeCells('B5:D5'); $sheet_dashboard->getStyle('B5')->applyFromArray($style_titulo_2);
            $sheet_dashboard->setCellValue('B5', 'Total de Salas');
            $sheet_dashboard->mergeCells('B6:D6'); $sheet_dashboard->getStyle('B6')->applyFromArray($style_valor_2);
            $sheet_dashboard->setCellValue('B6', $dados_kpis_adicionais['total_salas']);
            $sheet_dashboard->mergeCells('F5:H5'); $sheet_dashboard->getStyle('F5')->applyFromArray($style_titulo_2);
            $sheet_dashboard->setCellValue('F5', 'Total de Turmas');
            $sheet_dashboard->mergeCells('F6:H6'); $sheet_dashboard->getStyle('F6')->applyFromArray($style_valor_2);
            $sheet_dashboard->setCellValue('F6', $dados_kpis_adicionais['total_turmas']);
            $sheet_dashboard->mergeCells('J5:L5'); $sheet_dashboard->getStyle('J5')->applyFromArray($style_titulo_2);
            $sheet_dashboard->setCellValue('J5', 'Total de Alocações');
            $sheet_dashboard->mergeCells('J6:L6'); $sheet_dashboard->getStyle('J6')->applyFromArray($style_valor_2);
            $sheet_dashboard->setCellValue('J6', $dados_kpis_adicionais['total_alocacoes']);
            $sheet_dashboard->mergeCells('N5:P5'); $sheet_dashboard->getStyle('N5')->applyFromArray($style_titulo_2);
            $sheet_dashboard->setCellValue('N5', 'Média de Alocações/Dia');
            $sheet_dashboard->mergeCells('N6:P6'); $sheet_dashboard->getStyle('N6')->applyFromArray($style_valor_2);
            $sheet_dashboard->setCellValue('N6', $dados_kpis_adicionais['media_alocacoes_dia']);
        }
        // =================================================================

        // Gráfico de Status
        if ($dados_grafico_status && is_array($dados_grafico_status) && array_sum($dados_grafico_status) > 0) {
            // (Seu código existente e funcional, sem alterações)
            $sheet_dados_graficos->setCellValue('A1', 'Status');
            $sheet_dados_graficos->setCellValue('B1', 'Quantidade');
            $sheet_dados_graficos->getStyle('A1:B1')->getFont()->setBold(true);
            $mapa_cores = ['alocadas' => '198754', 'conflitos' => 'dc3545', 'pendentes' => 'ffc107'];
            $labels = array_keys($dados_grafico_status);
            $values = array_values($dados_grafico_status);
            $plot_colors = [];
            $chart_row = 2;
            foreach ($labels as $index => $label) {
                $sheet_dados_graficos->setCellValue('A' . $chart_row, ucfirst($label));
                $sheet_dados_graficos->setCellValue('B' . $chart_row, $values[$index]);
                $plot_colors[] = $mapa_cores[$label] ?? '808080';
                $chart_row++;
            }
            $num_data_points = count($labels);
            $data_range_end = 1 + $num_data_points;
            $dataSeriesLabels = [new \PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues('String', "'Dados dos Gráficos'!\$A\$2:\$A$" . $data_range_end, null, $num_data_points)];
            $xAxisTickValues = [new \PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues('String', "'Dados dos Gráficos'!\$A\$2:\$A$" . $data_range_end, null, $num_data_points)];
            $dataSeriesValues = [new \PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues('Number', "'Dados dos Gráficos'!\$B\$2:\$B$" . $data_range_end, null, $num_data_points, [], null, $plot_colors)];
            $series = new \PhpOffice\PhpSpreadsheet\Chart\DataSeries(\PhpOffice\PhpSpreadsheet\Chart\DataSeries::TYPE_DOUGHNUTCHART, null, range(0, $num_data_points - 1), $dataSeriesLabels, $xAxisTickValues, $dataSeriesValues);
            $layout = new \PhpOffice\PhpSpreadsheet\Chart\Layout();
            $layout->setShowVal(true)->setShowPercent(true);
            $plotArea = new \PhpOffice\PhpSpreadsheet\Chart\PlotArea($layout, [$series]);
            $legend = new \PhpOffice\PhpSpreadsheet\Chart\Legend(\PhpOffice\PhpSpreadsheet\Chart\Legend::POSITION_RIGHT, null, false);
            $title = new \PhpOffice\PhpSpreadsheet\Chart\Title('Distribuição por Status');
            $chart = new \PhpOffice\PhpSpreadsheet\Chart\Chart('chart_status', $title, $legend, $plotArea);
            $chart->setTopLeftPosition('B8');
            $chart->setBottomRightPosition('J27');
            $sheet_dashboard->addChart($chart);
        }

        // Gráfico de Ocupação por Horário
        if ($dados_grafico_ocupacao_horario && is_array($dados_grafico_ocupacao_horario) && count($dados_grafico_ocupacao_horario) > 0) {
            // (Seu código existente e funcional, renomeado para clareza)
            $sheet_dados_graficos->setCellValue('D1', 'Horário');
            $sheet_dados_graficos->setCellValue('E1', 'Aulas Alocadas');
            $sheet_dados_graficos->getStyle('D1:E1')->getFont()->setBold(true);
            $labels_ocupacao = array_keys($dados_grafico_ocupacao_horario);
            $values_ocupacao = array_values($dados_grafico_ocupacao_horario);
            $chart_row = 2;
            foreach ($labels_ocupacao as $index => $label) {
                $sheet_dados_graficos->setCellValue('D' . $chart_row, $label);
                $sheet_dados_graficos->setCellValue('E' . $chart_row, $values_ocupacao[$index]);
                $chart_row++;
            }
            $num_data_points_ocupacao = count($labels_ocupacao);
            $data_range_end_ocupacao = 1 + $num_data_points_ocupacao;
            $dataSeriesLabels_ocupacao = [new \PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues('String', "'Dados dos Gráficos'!\$E\$1", null, 1)];
            $xAxisTickValues_ocupacao = [new \PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues('String', "'Dados dos Gráficos'!\$D\$2:\$D$" . $data_range_end_ocupacao, null, $num_data_points_ocupacao)];
            $dataSeriesValues_ocupacao = [new \PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues('Number', "'Dados dos Gráficos'!\$E\$2:\$E$" . $data_range_end_ocupacao, null, $num_data_points_ocupacao)];
            $series_ocupacao = new \PhpOffice\PhpSpreadsheet\Chart\DataSeries(\PhpOffice\PhpSpreadsheet\Chart\DataSeries::TYPE_BARCHART, \PhpOffice\PhpSpreadsheet\Chart\DataSeries::GROUPING_STANDARD, range(0, $num_data_points_ocupacao - 1), $dataSeriesLabels_ocupacao, $xAxisTickValues_ocupacao, $dataSeriesValues_ocupacao);
            $plotArea_ocupacao = new \PhpOffice\PhpSpreadsheet\Chart\PlotArea(null, [$series_ocupacao]);
            $title_ocupacao = new \PhpOffice\PhpSpreadsheet\Chart\Title('Ocupação por Horário');
            $legend_ocupacao = new \PhpOffice\PhpSpreadsheet\Chart\Legend(\PhpOffice\PhpSpreadsheet\Chart\Legend::POSITION_TOP, null, false);
            $chart_ocupacao = new \PhpOffice\PhpSpreadsheet\Chart\Chart('chart_ocupacao', $title_ocupacao, $legend_ocupacao, $plotArea_ocupacao);
            $chart_ocupacao->setTopLeftPosition('L8');
            $chart_ocupacao->setBottomRightPosition('W27');
            $sheet_dashboard->addChart($chart_ocupacao);
        }

        // =================================================================
        // >> ADIÇÃO 3: Adicionar o novo gráfico de Ocupação por Dia <<
        // =================================================================
        if ($dados_grafico_ocupacao_dia && is_array($dados_grafico_ocupacao_dia['labels']) && count($dados_grafico_ocupacao_dia['labels']) > 0) {
            $sheet_dados_graficos->setCellValue('G1', 'Dia da Semana');
            $sheet_dados_graficos->setCellValue('H1', 'Aulas Alocadas');
            $sheet_dados_graficos->getStyle('G1:H1')->getFont()->setBold(true);
            $chart_row = 2;
            foreach ($dados_grafico_ocupacao_dia['labels'] as $index => $label) {
                $sheet_dados_graficos->setCellValue('G' . $chart_row, $label);
                $sheet_dados_graficos->setCellValue('H' . $chart_row, $dados_grafico_ocupacao_dia['data'][$index]);
                $chart_row++;
            }
            $num_data_points_dia = count($dados_grafico_ocupacao_dia['labels']);
            $data_range_end_dia = 1 + $num_data_points_dia;
            $dataSeriesLabels_dia = [new \PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues('String', "'Dados dos Gráficos'!\$H\$1", null, 1)];
            $xAxisTickValues_dia = [new \PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues('String', "'Dados dos Gráficos'!\$G\$2:\$G$" . $data_range_end_dia, null, $num_data_points_dia)];
            $dataSeriesValues_dia = [new \PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues('Number', "'Dados dos Gráficos'!\$H\$2:\$H$" . $data_range_end_dia, null, $num_data_points_dia)];
            $series_dia = new \PhpOffice\PhpSpreadsheet\Chart\DataSeries(\PhpOffice\PhpSpreadsheet\Chart\DataSeries::TYPE_BARCHART, \PhpOffice\PhpSpreadsheet\Chart\DataSeries::GROUPING_STANDARD, range(0, $num_data_points_dia - 1), $dataSeriesLabels_dia, $xAxisTickValues_dia, $dataSeriesValues_dia);
            $plotArea_dia = new \PhpOffice\PhpSpreadsheet\Chart\PlotArea(null, [$series_dia]);
            $title_dia = new \PhpOffice\PhpSpreadsheet\Chart\Title('Ocupação por Dia da Semana');
            $legend_dia = new \PhpOffice\PhpSpreadsheet\Chart\Legend(\PhpOffice\PhpSpreadsheet\Chart\Legend::POSITION_TOP, null, false);
            $chart_dia = new \PhpOffice\PhpSpreadsheet\Chart\Chart('chart_dia', $title_dia, $legend_dia, $plotArea_dia);
            $chart_dia->setTopLeftPosition('B29'); // Posicionado abaixo do gráfico de status
            $chart_dia->setBottomRightPosition('J48');
            $sheet_dashboard->addChart($chart_dia);
        }
        // =================================================================

        // Gráfico de Eficiência por Sala
        if ($dados_grafico_eficiencia && is_array($dados_grafico_eficiencia) && count($dados_grafico_eficiencia) > 0) {
            // (Seu código existente e funcional, apenas reposicionado)
            $sheet_dados_graficos->setCellValue('J1', 'Sala');
            $sheet_dados_graficos->setCellValue('K1', 'Eficiência');
            $sheet_dados_graficos->getStyle('J1:K1')->getFont()->setBold(true);
            $labels_eficiencia = array_reverse(array_keys($dados_grafico_eficiencia));
            $values_eficiencia = array_reverse(array_values($dados_grafico_eficiencia));
            $chart_row = 2;
            foreach ($labels_eficiencia as $index => $label) {
                $sheet_dados_graficos->setCellValue('J' . $chart_row, $label);
                $sheet_dados_graficos->setCellValue('K' . $chart_row, $values_eficiencia[$index] / 100);
                $sheet_dados_graficos->getStyle('K' . $chart_row)->getNumberFormat()->setFormatCode(\PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_PERCENTAGE_0);
                $chart_row++;
            }
            $num_data_points_eficiencia = count($labels_eficiencia);
            $data_range_end_eficiencia = 1 + $num_data_points_eficiencia;
            $dataSeriesLabels_eficiencia = [new \PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues('String', "'Dados dos Gráficos'!\$K\$1", null, 1)];
            $xAxisTickValues_eficiencia = [new \PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues('String', "'Dados dos Gráficos'!\$J\$2:\$J$" . $data_range_end_eficiencia, null, $num_data_points_eficiencia)];
            $dataSeriesValues_eficiencia = [new \PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues('Number', "'Dados dos Gráficos'!\$K\$2:\$K$" . $data_range_end_eficiencia, null, $num_data_points_eficiencia)];
    $series_eficiencia = new \PhpOffice\PhpSpreadsheet\Chart\DataSeries(
        \PhpOffice\PhpSpreadsheet\Chart\DataSeries::TYPE_BARCHART, 
        \PhpOffice\PhpSpreadsheet\Chart\DataSeries::GROUPING_CLUSTERED, // << NOME CORRETO
        range(0, $num_data_points_eficiencia - 1), 
        $dataSeriesLabels_eficiencia, 
        $xAxisTickValues_eficiencia, 
        $dataSeriesValues_eficiencia
    );
            $plotArea_eficiencia = new \PhpOffice\PhpSpreadsheet\Chart\PlotArea(null, [$series_eficiencia]);
            $title_eficiencia = new \PhpOffice\PhpSpreadsheet\Chart\Title('Eficiência por Sala');
            $chart_eficiencia = new \PhpOffice\PhpSpreadsheet\Chart\Chart('chart_eficiencia', $title_eficiencia, null, $plotArea_eficiencia);
            $chart_eficiencia->setTopLeftPosition('L29'); // Posicionado ao lado do novo gráfico
            $chart_eficiencia->setBottomRightPosition('W48');
            $sheet_dashboard->addChart($chart_eficiencia);
        }
        
        // --- FINALIZAÇÃO ---
        $sheet_dados_graficos->setSheetState(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet::SHEETSTATE_HIDDEN);
        $spreadsheet->setActiveSheetIndex(1);
        $filename = "relatorio_dashboard_" . date('Y-m-d') . ".xlsx";
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->setIncludeCharts(true);
        $writer->save('php://output');
        exit;

    } catch (Throwable $e) {
        // Bloco de segurança
        if (ob_get_level() > 0) { ob_end_clean(); }
        header('Content-Type: text/plain');
        die("ERRO FATAL AO GERAR O RELATÓRIO: " . $e->getMessage());
    }
}

function obterStatus($database) {
    if (empty($_GET['periodo'])) {
    // Se o período não for fornecido, encerra a execução com um erro claro.
    http_response_code(400 ); // 400 = Bad Request
    echo json_encode(['success' => false, 'message' => 'O parâmetro "periodo" é obrigatório.']);
    exit; // Interrompe o script
}
$periodo = $_GET['periodo'];
    
    $stmt_turmas = $database->prepare("SELECT COUNT(*) as total FROM turmas WHERE periodo = ? AND ativo = 1");
    $stmt_turmas->execute([$periodo]);
    $total_turmas = $stmt_turmas->fetchColumn();
    
    $stmt_salas = $database->prepare("SELECT COUNT(*) as total FROM salas WHERE ativo = 1");
    $stmt_salas->execute();
    $total_salas = $stmt_salas->fetchColumn();
    
    $stmt_alocadas = $database->prepare("SELECT COUNT(DISTINCT turma_id) as total FROM ensalamento WHERE periodo = ? AND status = 'alocado'");
    $stmt_alocadas->execute([$periodo]);
    $turmas_alocadas = $stmt_alocadas->fetchColumn();
    
    return [
        'periodo' => $periodo,
        'total_turmas' => (int)$total_turmas,
        'total_salas' => (int)$total_salas,
        'turmas_alocadas' => (int)$turmas_alocadas,
        'status_geral' => ($total_turmas > 0) ? 'Pronto para ensalamento' : 'Sem turmas cadastradas'
    ];
}

function obterHistorico($database) {
    if (empty($_GET['periodo'])) {
    // Se o período não for fornecido, encerra a execução com um erro claro.
    http_response_code(400 ); // 400 = Bad Request
    echo json_encode(['success' => false, 'message' => 'O parâmetro "periodo" é obrigatório.']);
    exit; // Interrompe o script
}
$periodo = $_GET['periodo'];
    
    // Esta consulta agrupa por execução de ensalamento, assumindo que múltiplos INSERTs podem ter o mesmo created_at
    $stmt = $database->prepare("
        SELECT 
            DATE(created_at) as data_execucao,
            algoritmo_usado,
            COUNT(DISTINCT turma_id) as turmas_processadas,
            AVG(eficiencia) as eficiencia_media
        FROM ensalamento
        WHERE periodo = ?
        GROUP BY data_execucao, algoritmo_usado
        ORDER BY data_execucao DESC
        LIMIT 5
    ");
    
    $stmt->execute([$periodo]);
    $historico = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $historico;
}


function obterAnaliseDeConflitos($database) {
    if (empty($_GET['periodo'])) {
    // Se o período não for fornecido, encerra a execução com um erro claro.
    http_response_code(400 ); // 400 = Bad Request
    echo json_encode(['success' => false, 'message' => 'O parâmetro "periodo" é obrigatório.']);
    exit; // Interrompe o script
}
$periodo = $_GET['periodo'];

    // A primeira parte da sua função está correta e pode ser mantida
    $sql = "SELECT 
                t.sala_fixa_id,
                GROUP_CONCAT(t.id) as turmas_ids,
                COUNT(t.id) as total_turmas_na_sala
            FROM turmas t
            WHERE t.periodo = ? AND t.sala_fixa_id IS NOT NULL
            GROUP BY t.sala_fixa_id
            HAVING total_turmas_na_sala > 1";

    $stmt = $database->prepare($sql);
    $stmt->execute([$periodo]);
    $grupos_de_salas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $conflitos_reais = [];

    foreach ($grupos_de_salas as $grupo) {
        $ids_das_turmas = explode(',', $grupo['turmas_ids']);
        
        $placeholders = rtrim(str_repeat('?,', count($ids_das_turmas)), ',');
        $sql_turmas = "SELECT id, codigo, nome, horario_inicio, horario_fim, segunda, terca, quarta, quinta, sexta, sabado, sala_fixa_id FROM turmas WHERE id IN ($placeholders)";
        $stmt_turmas = $database->prepare($sql_turmas);
        $stmt_turmas->execute($ids_das_turmas);
        $turmas_na_sala = $stmt_turmas->fetchAll(PDO::FETCH_ASSOC);

        // Comparar cada par de turmas
        for ($i = 0; $i < count($turmas_na_sala); $i++) {
            for ($j = $i + 1; $j < count($turmas_na_sala); $j++) {
                $t1 = $turmas_na_sala[$i];
                $t2 = $turmas_na_sala[$j];

                // =================================================================
                // LÓGICA DE DETECÇÃO DE SOBREPOSIÇÃO (VERSÃO CORRIGIDA E PRECISA)
                // =================================================================

                // 1. Verificar se há sobreposição de horário
                $horario_colide = ($t1['horario_inicio'] < $t2['horario_fim']) && ($t1['horario_fim'] > $t2['horario_inicio']);

                if ($horario_colide) {
                    // 2. Se os horários colidem, verificar em QUAIS DIAS isso acontece
                    $dias_semana = ['segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado'];
                    $dias_reais_do_conflito = [];

                    foreach ($dias_semana as $dia) {
                        // O conflito só existe naquele dia se AMBAS as turmas ocorrerem nele
                        if ($t1[$dia] && $t2[$dia]) {
                            $dias_reais_do_conflito[] = ucfirst($dia);
                        }
                    }

                    // 3. Se encontramos pelo menos um dia de conflito, registrar o problema
                    if (!empty($dias_reais_do_conflito)) {
                        // Encontramos um conflito real!
                        $sala_info = $database->query("SELECT codigo, nome FROM salas WHERE id = " . $t1['sala_fixa_id'])->fetch();
                        
                        // 4. Calcular o intervalo de tempo exato da sobreposição
                        $inicio_conflito = max($t1['horario_inicio'], $t2['horario_inicio']);
                        $fim_conflito = min($t1['horario_fim'], $t2['horario_fim']);
                        
                        $conflitos_reais[] = [
                            'sala_codigo' => $sala_info['codigo'],
                            'sala_nome' => $sala_info['nome'],
                            'turma1_codigo' => $t1['codigo'],
                            'turma1_nome' => $t1['nome'],
                            'turma2_codigo' => $t2['codigo'],
                            'turma2_nome' => $t2['nome'],
                            'dias' => implode(', ', $dias_reais_do_conflito), // Apenas os dias da sobreposição
                            'horario' => substr($inicio_conflito, 0, 5) . ' - ' . substr($fim_conflito, 0, 5) // O horário exato do conflito
                        ];
                    }
                }
                // =================================================================
            }
        }
    }
    
    return $conflitos_reais;
}


?>

