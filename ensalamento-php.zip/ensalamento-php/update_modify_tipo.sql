-- Script para modificar coluna tipo na tabela salas
-- Execute este script se você já tem o sistema instalado

ALTER TABLE salas MODIFY COLUMN tipo ENUM('comum', 'laboratorio', 'auditorio', 'pratica', 'informatica') NULL DEFAULT 'comum';
