-- Script para adicionar coluna sala_fixa_id na tabela turmas
-- Execute este comando no seu banco de dados MySQL/MariaDB

ALTER TABLE turmas ADD COLUMN sala_fixa_id INT NULL DEFAULT NULL AFTER periodo;

-- Comentário: Esta coluna permitirá associar uma turma a uma sala específica de forma fixa
-- Valores possíveis:
-- NULL = Turma sem sala fixa (será alocada pelo algoritmo)
-- ID da sala = Turma tem sala fixa definida

