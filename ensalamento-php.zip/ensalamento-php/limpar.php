<?php
/**
 * Script de Limpeza e Reinstalação
 * Remove dados duplicados e reinstala o sistema
 */

header('Content-Type: application/json; charset=utf-8');

// Desabilitar exibição de erros
ini_set('display_errors', 0);
ini_set('log_errors', 1);

try {
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'limpar_banco':
            limparBanco();
            break;
            
        case 'reinstalar':
            reinstalarSistema();
            break;
            
        default:
            exibirPaginaLimpeza();
            break;
    }
    
} catch (Exception $e) {
    if (isset($_GET['action'])) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    } else {
        die('Erro: ' . $e->getMessage());
    }
}

function limparBanco() {
    require_once __DIR__ . '/config/database.php';
    
    try {
        $database->beginTransaction();
        
        // Desabilitar verificação de foreign keys temporariamente
        $database->exec("SET FOREIGN_KEY_CHECKS = 0");
        
        // Limpar tabelas na ordem correta
        $tabelas = ['ensalamento', 'logs', 'turmas', 'salas', 'usuarios', 'configuracoes'];
        
        foreach ($tabelas as $tabela) {
            try {
                $database->exec("DROP TABLE IF EXISTS {$tabela}");
            } catch (Exception $e) {
                // Ignorar se tabela não existe
            }
        }
        
        // Reabilitar verificação de foreign keys
        $database->exec("SET FOREIGN_KEY_CHECKS = 1");
        
        $database->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Banco de dados limpo com sucesso'
        ]);
        
    } catch (Exception $e) {
        $database->rollback();
        throw new Exception('Erro ao limpar banco: ' . $e->getMessage());
    }
}

function reinstalarSistema() {
    require_once __DIR__ . '/config/database.php';
    
    try {
        // Ler e executar schema SQL
        $schema = file_get_contents(__DIR__ . '/database/schema.sql');
        
        if ($schema === false) {
            throw new Exception('Não foi possível ler o arquivo schema.sql');
        }
        
        // Dividir em comandos individuais
        $comandos = explode(';', $schema);
        
        $database->beginTransaction();
        
        foreach ($comandos as $comando) {
            $comando = trim($comando);
            
            if (empty($comando) || substr($comando, 0, 2) === '--') {
                continue;
            }
            
            $database->exec($comando);
        }
        
        // Inserir dados iniciais
        inserirDadosIniciais($database);
        
        $database->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Sistema reinstalado com sucesso'
        ]);
        
    } catch (Exception $e) {
        $database->rollback();
        throw new Exception('Erro na reinstalação: ' . $e->getMessage());
    }
}

function inserirDadosIniciais($database) {
    // Inserir usuário administrador padrão
    $stmt = $database->prepare("
        INSERT IGNORE INTO usuarios (username, nome, email, senha, tipo, ativo) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        'admin',
        'Administrador',
        'admin@sistema.local',
        password_hash('admin123', PASSWORD_DEFAULT),
        'admin',
        1
    ]);
    
    // Inserir configurações padrão
    $configuracoes = [
        ['periodo_atual', '2025.1', 'Período letivo atual'],
        ['algoritmo_padrao', 'otimizado', 'Algoritmo padrão para ensalamento'],
        ['max_tentativas_ensalamento', '3', 'Máximo de tentativas por turma'],
        ['timeout_ensalamento', '300', 'Timeout em segundos'],
        ['backup_automatico', '0', 'Backup automático ativado'],
        ['logs_detalhados', '1', 'Logs detalhados ativados']
    ];
    
    $stmt = $database->prepare("
        INSERT IGNORE INTO configuracoes (chave, valor, descricao) 
        VALUES (?, ?, ?)
    ");
    
    foreach ($configuracoes as $config) {
        $stmt->execute($config);
    }
    
    // Inserir salas de exemplo (sem duplicatas)
    $salas = [
        ['A101', 'Sala A101', 'teorica', 40, 1, 'Sala teórica padrão'],
        ['A102', 'Sala A102', 'teorica', 35, 1, 'Sala teórica padrão'],
        ['L201', 'Laboratório 201', 'laboratorio', 20, 1, 'Laboratório de informática'],
        ['L202', 'Laboratório 202', 'laboratorio', 25, 1, 'Laboratório de química'],
        ['AUD01', 'Auditório Principal', 'auditorio', 100, 1, 'Auditório para eventos']
    ];
    
    $stmt = $database->prepare("
        INSERT IGNORE INTO salas (codigo, nome, tipo, capacidade, ativo, observacoes) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    
    foreach ($salas as $sala) {
        $stmt->execute($sala);
    }
    
    // Inserir turmas de exemplo (sem duplicatas)
    $turmas = [
        ['MAT102', 'Matemática I', 'Engenharia', '2025.1', '1', 'Prof. João Silva', 30, 'teorica', 60, '{"segunda": ["08:00-10:00"], "quarta": ["08:00-10:00"]}'],
        ['FIS201', 'Física II', 'Engenharia', '2025.1', '2', 'Prof. Maria Santos', 25, 'laboratorio', 40, '{"terca": ["14:00-16:00"], "quinta": ["14:00-16:00"]}'],
        ['QUI301', 'Química Orgânica', 'Química', '2025.1', '3', 'Prof. Carlos Lima', 20, 'laboratorio', 80, '{"segunda": ["14:00-18:00"]}']
    ];
    
    $stmt = $database->prepare("
        INSERT IGNORE INTO turmas (codigo, nome, curso, periodo, semestre, professor, num_alunos, tipo_aula, carga_horaria, horarios) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    foreach ($turmas as $turma) {
        $stmt->execute($turma);
    }
}

function exibirPaginaLimpeza() {
    header('Content-Type: text/html; charset=utf-8');
    ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Limpeza e Reinstalação - Sistema de Ensalamento</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-warning text-dark text-center">
                        <h3><i class="bi bi-exclamation-triangle"></i> Limpeza e Reinstalação</h3>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-warning">
                            <h5><i class="bi bi-exclamation-triangle"></i> Atenção!</h5>
                            <p>Esta ferramenta irá <strong>remover todos os dados</strong> do sistema e reinstalar do zero.</p>
                            <p><strong>Use apenas se:</strong></p>
                            <ul>
                                <li>Há erros de duplicação de dados</li>
                                <li>Tabelas estão corrompidas</li>
                                <li>Quer começar com dados limpos</li>
                            </ul>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <i class="bi bi-trash display-4 text-danger"></i>
                                        <h5 class="mt-3">Limpar Banco</h5>
                                        <p class="text-muted">Remove todas as tabelas e dados</p>
                                        <button class="btn btn-danger" onclick="limparBanco()">
                                            <i class="bi bi-trash"></i> Limpar
                                        </button>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <i class="bi bi-arrow-clockwise display-4 text-success"></i>
                                        <h5 class="mt-3">Reinstalar</h5>
                                        <p class="text-muted">Cria tabelas e dados iniciais</p>
                                        <button class="btn btn-success" onclick="reinstalarSistema()">
                                            <i class="bi bi-arrow-clockwise"></i> Reinstalar
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <div class="card">
                                <div class="card-body text-center">
                                    <i class="bi bi-magic display-4 text-primary"></i>
                                    <h5 class="mt-3">Processo Completo</h5>
                                    <p class="text-muted">Limpa e reinstala automaticamente</p>
                                    <button class="btn btn-primary btn-lg" onclick="processoCompleto()">
                                        <i class="bi bi-magic"></i> Limpar e Reinstalar
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <div id="resultado" class="mt-4"></div>
                        
                        <div class="text-center mt-4">
                            <a href="index.php" class="btn btn-secondary">
                                <i class="bi bi-house"></i> Voltar ao Sistema
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function mostrarResultado(mensagem, tipo = 'info') {
            const resultado = document.getElementById('resultado');
            resultado.innerHTML = `<div class="alert alert-${tipo}"><i class="bi bi-info-circle"></i> ${mensagem}</div>`;
        }
        
        function limparBanco() {
            if (!confirm('Tem certeza que deseja limpar TODOS os dados do banco?')) {
                return;
            }
            
            mostrarResultado('Limpando banco de dados...', 'warning');
            
            fetch('limpar.php?action=limpar_banco')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        mostrarResultado(data.message, 'success');
                    } else {
                        mostrarResultado('Erro: ' + data.message, 'danger');
                    }
                })
                .catch(error => {
                    mostrarResultado('Erro na comunicação: ' + error.message, 'danger');
                });
        }
        
        function reinstalarSistema() {
            mostrarResultado('Reinstalando sistema...', 'info');
            
            fetch('limpar.php?action=reinstalar')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        mostrarResultado(data.message + ' - Sistema pronto para uso!', 'success');
                    } else {
                        mostrarResultado('Erro: ' + data.message, 'danger');
                    }
                })
                .catch(error => {
                    mostrarResultado('Erro na comunicação: ' + error.message, 'danger');
                });
        }
        
        function processoCompleto() {
            if (!confirm('Tem certeza que deseja limpar TODOS os dados e reinstalar o sistema?')) {
                return;
            }
            
            mostrarResultado('Iniciando processo completo...', 'info');
            
            // Primeiro limpar
            fetch('limpar.php?action=limpar_banco')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        mostrarResultado('Banco limpo. Reinstalando...', 'warning');
                        
                        // Depois reinstalar
                        return fetch('limpar.php?action=reinstalar');
                    } else {
                        throw new Error(data.message);
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        mostrarResultado('✅ Processo completo! Sistema reinstalado com sucesso!', 'success');
                        setTimeout(() => {
                            window.location.href = 'index.php';
                        }, 3000);
                    } else {
                        throw new Error(data.message);
                    }
                })
                .catch(error => {
                    mostrarResultado('Erro: ' + error.message, 'danger');
                });
        }
    </script>
</body>
</html>
    <?php
}
?>

