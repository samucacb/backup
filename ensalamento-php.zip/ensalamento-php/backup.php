<?php
/**
 * Sistema de Backup
 * Gerencia backup e restauração dos dados do sistema
 */

header('Content-Type: application/json');

require_once __DIR__ . '/config/database.php';

try {
    $action = $_GET['action'] ?? $_GET['tipo'] ?? '';
    
    switch ($action) {
        case 'completo':
            gerarBackupCompleto();
            break;
            
        case 'dados':
            gerarBackupDados();
            break;
            
        case 'configuracoes':
            gerarBackupConfiguracoes();
            break;
            
        case 'restaurar':
            restaurarBackup();
            break;
            
        default:
            throw new Exception('Ação não reconhecida');
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

function gerarBackupCompleto() {
    global $database;
    
    $timestamp = date('Y-m-d_H-i-s');
    $filename = "backup_completo_{$timestamp}.sql";
    
    // Configurar headers para download
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Transfer-Encoding: binary');
    
    // Obter lista de tabelas
    $stmt = $database->query("SHOW TABLES");
    $tabelas = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Cabeçalho do backup
    echo "-- Backup Completo do Sistema de Ensalamento\n";
    echo "-- Gerado em: " . date('Y-m-d H:i:s') . "\n";
    echo "-- Versão: 1.0.0\n\n";
    
    echo "SET FOREIGN_KEY_CHECKS = 0;\n";
    echo "SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n";
    echo "SET AUTOCOMMIT = 0;\n";
    echo "START TRANSACTION;\n\n";
    
    foreach ($tabelas as $tabela) {
        // Estrutura da tabela
        $stmt = $database->query("SHOW CREATE TABLE `$tabela`");
        $createTable = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "-- Estrutura da tabela `$tabela`\n";
        echo "DROP TABLE IF EXISTS `$tabela`;\n";
        echo $createTable['Create Table'] . ";\n\n";
        
        // Dados da tabela
        $stmt = $database->query("SELECT * FROM `$tabela`");
        $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($dados)) {
            echo "-- Dados da tabela `$tabela`\n";
            
            $colunas = array_keys($dados[0]);
            $colunasStr = '`' . implode('`, `', $colunas) . '`';
            
            echo "INSERT INTO `$tabela` ($colunasStr) VALUES\n";
            
            $valores = [];
            foreach ($dados as $linha) {
                $valoresLinha = [];
                foreach ($linha as $valor) {
                    if ($valor === null) {
                        $valoresLinha[] = 'NULL';
                    } else {
                        $valoresLinha[] = "'" . addslashes($valor) . "'";
                    }
                }
                $valores[] = '(' . implode(', ', $valoresLinha) . ')';
            }
            
            echo implode(",\n", $valores) . ";\n\n";
        }
    }
    
    echo "SET FOREIGN_KEY_CHECKS = 1;\n";
    echo "COMMIT;\n";
    
    exit;
}

function gerarBackupDados() {
    global $database;
    
    $timestamp = date('Y-m-d_H-i-s');
    $filename = "backup_dados_{$timestamp}.sql";
    
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    // Tabelas de dados (excluindo logs e configurações)
    $tabelasDados = ['salas', 'turmas', 'ensalamento', 'usuarios'];
    
    echo "-- Backup de Dados do Sistema de Ensalamento\n";
    echo "-- Gerado em: " . date('Y-m-d H:i:s') . "\n\n";
    
    echo "SET FOREIGN_KEY_CHECKS = 0;\n";
    echo "START TRANSACTION;\n\n";
    
    foreach ($tabelasDados as $tabela) {
        // Verificar se a tabela existe
        $stmt = $database->prepare("SHOW TABLES LIKE ?");
        $stmt->execute([$tabela]);
        
        if ($stmt->rowCount() == 0) {
            continue;
        }
        
        echo "-- Limpando tabela `$tabela`\n";
        echo "DELETE FROM `$tabela`;\n\n";
        
        // Dados da tabela
        $stmt = $database->query("SELECT * FROM `$tabela`");
        $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($dados)) {
            echo "-- Dados da tabela `$tabela`\n";
            
            $colunas = array_keys($dados[0]);
            $colunasStr = '`' . implode('`, `', $colunas) . '`';
            
            echo "INSERT INTO `$tabela` ($colunasStr) VALUES\n";
            
            $valores = [];
            foreach ($dados as $linha) {
                $valoresLinha = [];
                foreach ($linha as $valor) {
                    if ($valor === null) {
                        $valoresLinha[] = 'NULL';
                    } else {
                        $valoresLinha[] = "'" . addslashes($valor) . "'";
                    }
                }
                $valores[] = '(' . implode(', ', $valoresLinha) . ')';
            }
            
            echo implode(",\n", $valores) . ";\n\n";
        }
    }
    
    echo "SET FOREIGN_KEY_CHECKS = 1;\n";
    echo "COMMIT;\n";
    
    exit;
}

function gerarBackupConfiguracoes() {
    global $database;
    
    $timestamp = date('Y-m-d_H-i-s');
    $filename = "backup_config_{$timestamp}.json";
    
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    // Buscar configurações
    $stmt = $database->query("SELECT * FROM configuracoes ORDER BY chave");
    $configuracoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Buscar usuários (sem senhas)
    $stmt = $database->query("SELECT id, username, nome, email, tipo, ativo, created_at FROM usuarios ORDER BY id");
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $backup = [
        'sistema' => 'Sistema de Ensalamento',
        'versao' => '1.0.0',
        'data_backup' => date('Y-m-d H:i:s'),
        'tipo' => 'configuracoes',
        'configuracoes' => $configuracoes,
        'usuarios' => $usuarios
    ];
    
    echo json_encode($backup, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

function restaurarBackup() {
    global $database;
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método não permitido');
    }
    
    if (!isset($_FILES['arquivo']) || $_FILES['arquivo']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Arquivo de backup não enviado ou corrompido');
    }
    
    $arquivo = $_FILES['arquivo'];
    $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
    
    if ($extensao === 'sql') {
        restaurarBackupSQL($arquivo['tmp_name']);
    } elseif ($extensao === 'json') {
        restaurarBackupJSON($arquivo['tmp_name']);
    } else {
        throw new Exception('Formato de arquivo não suportado. Use .sql ou .json');
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Backup restaurado com sucesso'
    ]);
}

function restaurarBackupSQL($arquivo) {
    global $database;
    
    $sql = file_get_contents($arquivo);
    
    if ($sql === false) {
        throw new Exception('Erro ao ler arquivo de backup');
    }
    
    // Dividir em comandos SQL
    $comandos = explode(';', $sql);
    
    $database->beginTransaction();
    
    try {
        foreach ($comandos as $comando) {
            $comando = trim($comando);
            
            if (empty($comando) || substr($comando, 0, 2) === '--') {
                continue;
            }
            
            $database->exec($comando);
        }
        
        $database->commit();
        
    } catch (Exception $e) {
        $database->rollback();
        throw new Exception('Erro ao restaurar backup SQL: ' . $e->getMessage());
    }
}

function restaurarBackupJSON($arquivo) {
    global $database;
    
    $json = file_get_contents($arquivo);
    $backup = json_decode($json, true);
    
    if ($backup === null) {
        throw new Exception('Arquivo JSON inválido');
    }
    
    if (!isset($backup['configuracoes']) && !isset($backup['usuarios'])) {
        throw new Exception('Backup JSON não contém dados válidos');
    }
    
    $database->beginTransaction();
    
    try {
        // Restaurar configurações
        if (isset($backup['configuracoes'])) {
            $database->exec("DELETE FROM configuracoes");
            
            $stmt = $database->prepare("INSERT INTO configuracoes (chave, valor, descricao) VALUES (?, ?, ?)");
            
            foreach ($backup['configuracoes'] as $config) {
                $stmt->execute([
                    $config['chave'],
                    $config['valor'],
                    $config['descricao'] ?? ''
                ]);
            }
        }
        
        // Restaurar usuários (exceto senhas)
        if (isset($backup['usuarios'])) {
            $stmt = $database->prepare("
                UPDATE usuarios SET 
                nome = ?, email = ?, tipo = ?, ativo = ? 
                WHERE username = ?
            ");
            
            foreach ($backup['usuarios'] as $usuario) {
                $stmt->execute([
                    $usuario['nome'],
                    $usuario['email'],
                    $usuario['tipo'],
                    $usuario['ativo'],
                    $usuario['username']
                ]);
            }
        }
        
        $database->commit();
        
    } catch (Exception $e) {
        $database->rollback();
        throw new Exception('Erro ao restaurar backup JSON: ' . $e->getMessage());
    }
}

function registrarLog($acao, $detalhes = '') {
    global $database;
    
    try {
        $stmt = $database->prepare("
            INSERT INTO logs (acao, tabela, detalhes, usuario, ip) 
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $acao,
            'backup',
            $detalhes,
            'sistema',
            $_SERVER['REMOTE_ADDR'] ?? 'localhost'
        ]);
        
    } catch (Exception $e) {
        // Log silencioso - não interromper o backup por erro de log
        error_log('Erro ao registrar log de backup: ' . $e->getMessage());
    }
}
?>

