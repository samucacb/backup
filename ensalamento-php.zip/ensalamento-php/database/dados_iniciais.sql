-- Dados Iniciais do Sistema de Ensalamento
-- Versão: 2.0 - Atualizado para nova estrutura

-- Inserir configurações padrão
INSERT IGNORE INTO configuracoes (chave, valor, descricao, categoria) VALUES
('periodo_atual', '2025.1', 'Período letivo atual', 'sistema'),
('algoritmo_padrao', 'otimizado', 'Algoritmo padrão para ensalamento', 'ensalamento'),
('max_tentativas_ensalamento', '3', 'Máximo de tentativas por turma', 'ensalamento'),
('timeout_ensalamento', '300', 'Timeout em segundos', 'sistema'),
('backup_automatico', '0', 'Backup automático ativado', 'sistema'),
('logs_detalhados', '1', 'Logs detalhados ativados', 'sistema');

-- Inserir usuário administrador padrão
INSERT IGNORE INTO usuarios (username, nome, email, senha, tipo, ativo) VALUES
('admin', 'Administrador', 'admin@sistema.local', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1);

-- Inserir salas de exemplo
INSERT IGNORE INTO salas (codigo, nome, tipo, capacidade, ativo, observacoes) VALUES
('A101', 'Sala A101', 'comum', 40, 1, 'Sala teórica padrão'),
('A102', 'Sala A102', 'comum', 35, 1, 'Sala teórica padrão'),
('A103', 'Sala A103', 'comum', 30, 1, 'Sala teórica pequena'),
('L201', 'Laboratório 201', 'laboratorio', 20, 1, 'Laboratório de informática'),
('L202', 'Laboratório 202', 'laboratorio', 25, 1, 'Laboratório de química'),
('L203', 'Laboratório 203', 'laboratorio', 15, 1, 'Laboratório de física'),
('AUD01', 'Auditório Principal', 'auditorio', 100, 1, 'Auditório para eventos'),
('P301', 'Sala Prática 301', 'pratica', 25, 1, 'Sala para aulas práticas'),
('I401', 'Lab Informática 401', 'informatica', 30, 1, 'Laboratório de informática avançado');

-- Inserir turmas de exemplo com nova estrutura
INSERT IGNORE INTO turmas (codigo, nome, curso, periodo, semestre, professor, num_alunos, tipo_aula, carga_horaria, horario_inicio, horario_fim, segunda, terca, quarta, quinta, sexta, sabado, turno, ativo) VALUES
('MAT102', 'Matemática I', 'Engenharia', '2025.1', '1', 'Prof. João Silva', 30, 'teorica', 60, '08:00:00', '10:00:00', 1, 0, 1, 0, 0, 0, 'matutino', 1),
('FIS201', 'Física II', 'Engenharia', '2025.1', '2', 'Prof. Maria Santos', 25, 'pratica', 40, '14:00:00', '16:00:00', 0, 1, 0, 1, 0, 0, 'vespertino', 1),
('QUI301', 'Química Orgânica', 'Química', '2025.1', '3', 'Prof. Carlos Lima', 20, 'pratica', 80, '14:00:00', '18:00:00', 1, 0, 0, 0, 0, 0, 'vespertino', 1),
('INF101', 'Introdução à Programação', 'Ciência da Computação', '2025.1', '1', 'Prof. Ana Costa', 35, 'pratica', 60, '08:00:00', '10:00:00', 0, 1, 0, 1, 0, 0, 'matutino', 1),
('BIO201', 'Biologia Molecular', 'Biologia', '2025.1', '2', 'Prof. Pedro Oliveira', 28, 'pratica', 40, '10:00:00', '12:00:00', 1, 0, 1, 0, 1, 0, 'matutino', 1),
('ENG301', 'Resistência dos Materiais', 'Engenharia', '2025.1', '3', 'Prof. Roberto Ferreira', 32, 'teorica', 80, '19:00:00', '21:00:00', 0, 1, 0, 1, 0, 0, 'noturno', 1),
('ADM101', 'Administração Geral', 'Administração', '2025.1', '1', 'Prof. Lucia Mendes', 45, 'teorica', 60, '19:00:00', '21:00:00', 1, 0, 1, 0, 0, 0, 'noturno', 1),
('DIR201', 'Direito Civil', 'Direito', '2025.1', '2', 'Prof. Fernando Alves', 40, 'teorica', 80, '20:00:00', '22:00:00', 0, 0, 1, 0, 1, 0, 'noturno', 1);

-- Inserir alguns ensalamentos de exemplo
INSERT IGNORE INTO ensalamento (turma_id, sala_id, status, created_at) VALUES
(1, 1, 'alocada', NOW()),
(2, 4, 'alocada', NOW()),
(3, 5, 'alocada', NOW()),
(4, 9, 'alocada', NOW()),
(5, 6, 'alocada', NOW());

-- Verificar se os dados foram inseridos
SELECT 'Dados iniciais inseridos com sucesso!' as status;

