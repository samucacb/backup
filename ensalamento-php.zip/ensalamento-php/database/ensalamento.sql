-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 04/09/2025 às 19:58
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `ensalamento`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `configuracoes`
--

CREATE TABLE `configuracoes` (
  `id` int(11) NOT NULL,
  `chave` varchar(100) NOT NULL,
  `valor` text NOT NULL,
  `categoria` varchar(50) DEFAULT 'geral',
  `descricao` text DEFAULT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_atualizacao` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `configuracoes`
--

INSERT INTO `configuracoes` (`id`, `chave`, `valor`, `categoria`, `descricao`, `data_criacao`, `data_atualizacao`) VALUES
(1, 'periodo_atual', '2025.1', 'sistema', 'Período letivo atual', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(2, 'algoritmo_padrao', 'otimizado', 'ensalamento', 'Algoritmo padrão para ensalamento', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(3, 'max_tentativas_ensalamento', '3', 'ensalamento', 'Máximo de tentativas por turma', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(4, 'timeout_ensalamento', '300', 'sistema', 'Timeout em segundos', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(5, 'backup_automatico', '0', 'sistema', 'Backup automático ativado', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(6, 'logs_detalhados', '1', 'sistema', 'Logs detalhados ativados', '2025-09-03 12:55:06', '2025-09-03 12:55:06');

-- --------------------------------------------------------

--
-- Estrutura para tabela `ensalamento`
--

CREATE TABLE `ensalamento` (
  `id` int(11) NOT NULL,
  `turma_id` int(11) NOT NULL,
  `sala_id` int(11) DEFAULT NULL,
  `dia_semana` enum('segunda','terca','quarta','quinta','sexta','sabado','domingo') DEFAULT NULL,
  `horario_inicio` time DEFAULT NULL,
  `horario_fim` time DEFAULT NULL,
  `status` enum('pendente','alocado','conflito','cancelado') DEFAULT 'pendente',
  `eficiencia` decimal(5,2) DEFAULT NULL,
  `algoritmo_usado` varchar(50) DEFAULT NULL,
  `observacoes` text DEFAULT NULL,
  `periodo` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `ensalamento`
--

INSERT INTO `ensalamento` (`id`, `turma_id`, `sala_id`, `dia_semana`, `horario_inicio`, `horario_fim`, `status`, `eficiencia`, `algoritmo_usado`, `observacoes`, `periodo`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(2, 2, 4, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(3, 3, 5, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(4, 4, 9, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(5, 5, 6, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(6, 1, 1, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2025-09-03 12:57:07', '2025-09-03 12:57:07'),
(7, 2, 4, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2025-09-03 12:57:07', '2025-09-03 12:57:07'),
(8, 3, 5, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2025-09-03 12:57:07', '2025-09-03 12:57:07'),
(9, 4, 9, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2025-09-03 12:57:07', '2025-09-03 12:57:07'),
(10, 5, 6, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2025-09-03 12:57:07', '2025-09-03 12:57:07'),
(11, 1, 3, 'segunda', '08:00:00', '10:00:00', 'alocado', 100.00, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(12, 1, 3, 'quarta', '08:00:00', '10:00:00', 'alocado', 100.00, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(13, 2, 5, 'terca', '14:00:00', '16:00:00', 'alocado', 100.00, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(14, 2, 5, 'quinta', '14:00:00', '16:00:00', 'alocado', 100.00, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(15, 3, 4, 'segunda', '14:00:00', '18:00:00', 'alocado', 100.00, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(16, 4, 2, 'terca', '08:00:00', '10:00:00', 'alocado', 100.00, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(17, 4, 2, 'quinta', '08:00:00', '10:00:00', 'alocado', 100.00, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(18, 5, 3, 'segunda', '10:00:00', '12:00:00', 'alocado', 93.33, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(19, 5, 3, 'quarta', '10:00:00', '12:00:00', 'alocado', 93.33, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(20, 5, 3, 'sexta', '10:00:00', '12:00:00', 'alocado', 93.33, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(21, 6, 2, 'terca', '19:00:00', '21:00:00', 'alocado', 91.43, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(22, 6, 2, 'quinta', '19:00:00', '21:00:00', 'alocado', 91.43, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(23, 7, 7, 'segunda', '19:00:00', '21:00:00', 'alocado', 45.00, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(24, 7, 7, 'quarta', '19:00:00', '21:00:00', 'alocado', 45.00, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(25, 8, 1, 'quarta', '20:00:00', '22:00:00', 'alocado', 100.00, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35'),
(26, 8, 1, 'sexta', '20:00:00', '22:00:00', 'alocado', 100.00, 'otimizado', NULL, '2025.1', '2025-09-04 17:42:35', '2025-09-04 17:42:35');

-- --------------------------------------------------------

--
-- Estrutura para tabela `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  `acao` varchar(100) NOT NULL,
  `tabela` varchar(50) DEFAULT NULL,
  `registro_id` int(11) DEFAULT NULL,
  `dados_anteriores` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`dados_anteriores`)),
  `dados_novos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`dados_novos`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `periodos`
--

CREATE TABLE `periodos` (
  `id` int(11) NOT NULL,
  `periodo` varchar(10) NOT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `periodos`
--

INSERT INTO `periodos` (`id`, `periodo`, `ativo`, `data_criacao`) VALUES
(1, '2025.1', 1, '2025-09-03 12:57:47');

-- --------------------------------------------------------

--
-- Estrutura para tabela `salas`
--

CREATE TABLE `salas` (
  `id` int(11) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `predio` varchar(100) DEFAULT NULL,
  `bloco` varchar(100) DEFAULT NULL,
  `capacidade` int(11) NOT NULL,
  `tipo` enum('comum','laboratorio','auditorio','pratica','informatica') DEFAULT 'comum',
  `descricao` text DEFAULT NULL,
  `recursos` text DEFAULT NULL,
  `localizacao` varchar(200) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `observacoes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `salas`
--

INSERT INTO `salas` (`id`, `codigo`, `nome`, `predio`, `bloco`, `capacidade`, `tipo`, `descricao`, `recursos`, `localizacao`, `ativo`, `observacoes`, `created_at`, `updated_at`) VALUES
(1, 'A101', 'Sala A101', 'predio 1', 'bloco a', 40, 'comum', NULL, '', '', 1, 'Sala teórica padrão', '2025-09-03 12:55:06', '2025-09-03 16:01:38'),
(2, 'A102', 'Sala A102', NULL, NULL, 35, 'comum', NULL, NULL, NULL, 1, 'Sala teórica padrão', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(3, 'A103', 'Sala A103', NULL, NULL, 30, 'comum', NULL, NULL, NULL, 1, 'Sala teórica pequena', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(4, 'L201', 'Laboratório 201', NULL, NULL, 20, 'laboratorio', NULL, NULL, NULL, 1, 'Laboratório de informática', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(5, 'L202', 'Laboratório 202', NULL, NULL, 25, 'laboratorio', NULL, NULL, NULL, 1, 'Laboratório de química', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(6, 'L203', 'Laboratório 203', NULL, NULL, 15, 'laboratorio', NULL, NULL, NULL, 1, 'Laboratório de física', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(7, 'AUD01', 'Auditório Principal', NULL, NULL, 100, 'auditorio', NULL, NULL, NULL, 1, 'Auditório para eventos', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(8, 'P301', 'Sala Prática 301', NULL, NULL, 25, 'pratica', NULL, NULL, NULL, 1, 'Sala para aulas práticas', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(9, 'I401', 'Lab Informática 401', NULL, NULL, 30, 'informatica', NULL, NULL, NULL, 1, 'Laboratório de informática avançado', '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(19, 'LAB01', 'Laboratório de Informática', 'Prédio A', 'Bloco 1', 30, 'laboratorio', NULL, 'Projetor, Ar Condicionado', '1º Andar, sala 101', 1, NULL, '2025-09-04 17:44:00', '2025-09-04 17:44:00'),
(20, 'SALA101', 'Sala de Aula 101', 'Prédio B', 'Bloco 2', 50, 'comum', NULL, 'Quadro branco, Projetor', '2º Andar, corredor A', 1, NULL, '2025-09-04 17:44:00', '2025-09-04 17:44:00'),
(21, 'SALA205', 'Sala de Práticas Manuais', 'Prédio C', 'Oficinas', 25, 'pratica', NULL, 'Bancadas, Ferramentas', 'Setor de Oficinas', 1, NULL, '2025-09-04 17:44:00', '2025-09-04 17:44:00'),
(22, 'INFO03', 'Laboratório de Redes', 'Prédio A', 'Bloco 2', 20, 'informatica', NULL, 'Roteadores, Switch, PC', '2º Andar, sala 203', 1, NULL, '2025-09-04 17:44:00', '2025-09-04 17:44:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `turmas`
--

CREATE TABLE `turmas` (
  `id` int(11) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `curso` varchar(100) NOT NULL,
  `periodo` varchar(20) NOT NULL,
  `sala_fixa_id` int(11) DEFAULT NULL,
  `semestre` varchar(10) NOT NULL,
  `professor` varchar(200) DEFAULT NULL,
  `num_alunos` int(11) NOT NULL,
  `tipo_aula` enum('teorica','pratica','laboratorio','seminario','estagio') NOT NULL DEFAULT 'teorica',
  `carga_horaria` int(11) DEFAULT 0,
  `horario_inicio` time DEFAULT NULL,
  `horario_fim` time DEFAULT NULL,
  `segunda` tinyint(1) DEFAULT 0,
  `terca` tinyint(1) DEFAULT 0,
  `quarta` tinyint(1) DEFAULT 0,
  `quinta` tinyint(1) DEFAULT 0,
  `sexta` tinyint(1) DEFAULT 0,
  `sabado` tinyint(1) DEFAULT 0,
  `turno` enum('matutino','vespertino','noturno','integral') DEFAULT 'matutino',
  `observacoes` text DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `turmas`
--

INSERT INTO `turmas` (`id`, `codigo`, `nome`, `curso`, `periodo`, `sala_fixa_id`, `semestre`, `professor`, `num_alunos`, `tipo_aula`, `carga_horaria`, `horario_inicio`, `horario_fim`, `segunda`, `terca`, `quarta`, `quinta`, `sexta`, `sabado`, `turno`, `observacoes`, `ativo`, `created_at`, `updated_at`) VALUES
(1, 'MAT102', 'Matemática I', 'Engenharia', '2025.1', NULL, '1', 'Prof. João Silva', 30, 'teorica', 60, '08:00:00', '10:00:00', 1, 0, 1, 0, 0, 0, 'matutino', NULL, 1, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(2, 'FIS201', 'Física II', 'Engenharia', '2025.1', NULL, '2', 'Prof. Maria Santos', 25, 'pratica', 40, '14:00:00', '16:00:00', 0, 1, 0, 1, 0, 0, 'vespertino', NULL, 1, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(3, 'QUI301', 'Química Orgânica', 'Química', '2025.1', NULL, '3', 'Prof. Carlos Lima', 20, 'pratica', 80, '14:00:00', '18:00:00', 1, 0, 0, 0, 0, 0, 'vespertino', NULL, 1, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(4, 'INF101', 'Introdução à Programação', 'Ciência da Computação', '2025.1', NULL, '1', 'Prof. Ana Costa', 35, 'pratica', 60, '08:00:00', '10:00:00', 0, 1, 0, 1, 0, 0, 'matutino', NULL, 1, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(5, 'BIO201', 'Biologia Molecular', 'Biologia', '2025.1', NULL, '2', 'Prof. Pedro Oliveira', 28, 'pratica', 40, '10:00:00', '12:00:00', 1, 0, 1, 0, 1, 0, 'matutino', NULL, 1, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(6, 'ENG301', 'Resistência dos Materiais', 'Engenharia', '2025.1', NULL, '3', 'Prof. Roberto Ferreira', 32, 'teorica', 80, '19:00:00', '21:00:00', 0, 1, 0, 1, 0, 0, 'noturno', NULL, 1, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(7, 'ADM101', 'Administração Geral', 'Administração', '2025.1', NULL, '1', 'Prof. Lucia Mendes', 45, 'teorica', 60, '19:00:00', '21:00:00', 1, 0, 1, 0, 0, 0, 'noturno', NULL, 1, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(8, 'DIR201', 'Direito Civil', 'Direito', '2025.1', NULL, '2', 'Prof. Fernando Alves', 40, 'teorica', 80, '20:00:00', '22:00:00', 0, 0, 1, 0, 1, 0, 'noturno', NULL, 1, '2025-09-03 12:55:06', '2025-09-03 12:55:06'),
(17, 'AAAAAA', 'SALA A', 'DIREITO', '2025.1', NULL, '', 'MARIA', 50, 'teorica', 50, '08:00:00', '12:00:00', 1, 1, 1, 0, 0, 0, 'matutino', 'OBSSSSSSS', 1, '2025-09-04 17:45:30', '2025-09-04 17:45:30'),
(18, 'BBBB', 'BBB', 'Engenharia', '2025.1', 1, '', 'Prof. Maria Santos', 50, 'teorica', 50, '08:00:00', '12:00:00', 0, 1, 1, 1, 0, 0, 'matutino', 'SASASA', 1, '2025-09-04 17:46:04', '2025-09-04 17:46:04');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` enum('admin','coordenador','professor','usuario') DEFAULT 'usuario',
  `ativo` tinyint(1) DEFAULT 1,
  `ultimo_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `username`, `nome`, `email`, `senha`, `tipo`, `ativo`, `ultimo_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrador', 'admin@sistema.local', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1, NULL, '2025-09-03 12:55:06', '2025-09-03 12:55:06');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `configuracoes`
--
ALTER TABLE `configuracoes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `chave` (`chave`);

--
-- Índices de tabela `ensalamento`
--
ALTER TABLE `ensalamento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_turma` (`turma_id`),
  ADD KEY `idx_sala` (`sala_id`),
  ADD KEY `idx_periodo` (`periodo`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_dia_horario` (`dia_semana`,`horario_inicio`);

--
-- Índices de tabela `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_usuario` (`usuario`),
  ADD KEY `idx_acao` (`acao`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Índices de tabela `periodos`
--
ALTER TABLE `periodos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `periodo` (`periodo`);

--
-- Índices de tabela `salas`
--
ALTER TABLE `salas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD KEY `idx_tipo_capacidade` (`tipo`,`capacidade`),
  ADD KEY `idx_ativo` (`ativo`);

--
-- Índices de tabela `turmas`
--
ALTER TABLE `turmas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD KEY `idx_periodo` (`periodo`),
  ADD KEY `idx_curso` (`curso`),
  ADD KEY `idx_tipo_aula` (`tipo_aula`),
  ADD KEY `idx_turno` (`turno`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_username` (`username`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_tipo` (`tipo`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `configuracoes`
--
ALTER TABLE `configuracoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `ensalamento`
--
ALTER TABLE `ensalamento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de tabela `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `periodos`
--
ALTER TABLE `periodos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `salas`
--
ALTER TABLE `salas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de tabela `turmas`
--
ALTER TABLE `turmas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `ensalamento`
--
ALTER TABLE `ensalamento`
  ADD CONSTRAINT `ensalamento_ibfk_1` FOREIGN KEY (`turma_id`) REFERENCES `turmas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ensalamento_ibfk_2` FOREIGN KEY (`sala_id`) REFERENCES `salas` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
