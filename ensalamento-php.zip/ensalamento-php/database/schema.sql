-- Sistema de Ensalamento - Schema SQL
-- Versão: 1.0 - Corrigido
-- Autor: Manus AI

-- Tabela de Salas
CREATE TABLE IF NOT EXISTS salas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(50) NOT NULL UNIQUE,
    nome VARCHAR(100) NOT NULL,
    capacidade INT NOT NULL,
    tipo ENUM('comum', 'laboratorio', 'auditorio', 'pratica', 'informatica') NULL DEFAULT 'comum',
    descricao TEXT,
    recursos TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
    localizacao VARCHAR(200),
    ativo BOOLEAN DEFAULT TRUE,
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_tipo_capacidade (tipo, capacidade),
    INDEX idx_ativo (ativo)
);

-- Tabela de Turmas
CREATE TABLE IF NOT EXISTS turmas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(50) NOT NULL UNIQUE,
    nome VARCHAR(200) NOT NULL,
    curso VARCHAR(100) NOT NULL,
    periodo VARCHAR(20) NOT NULL,
    sala_fixa_id INT NULL DEFAULT NULL,
    semestre VARCHAR(10) NOT NULL,
    professor VARCHAR(200),
    num_alunos INT NOT NULL,
    tipo_aula ENUM('teorica', 'pratica', 'laboratorio', 'seminario', 'estagio') NOT NULL DEFAULT 'teorica',
    carga_horaria INT DEFAULT 0,
    horario_inicio TIME,
    horario_fim TIME,
    segunda BOOLEAN DEFAULT 0,
    terca BOOLEAN DEFAULT 0,
    quarta BOOLEAN DEFAULT 0,
    quinta BOOLEAN DEFAULT 0,
    sexta BOOLEAN DEFAULT 0,
    sabado BOOLEAN DEFAULT 0,
    turno ENUM('matutino', 'vespertino', 'noturno', 'integral') DEFAULT 'matutino',
    observacoes TEXT,
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_periodo (periodo),
    INDEX idx_curso (curso),
    INDEX idx_tipo_aula (tipo_aula),
    INDEX idx_turno (turno)
);

-- Tabela de Usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    nome VARCHAR(200) NOT NULL,
    email VARCHAR(200) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('admin', 'coordenador', 'professor', 'usuario') DEFAULT 'usuario',
    ativo BOOLEAN DEFAULT TRUE,
    ultimo_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_tipo (tipo)
);

-- Tabela de Configurações
CREATE TABLE IF NOT EXISTS configuracoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chave VARCHAR(100) NOT NULL UNIQUE,
    valor TEXT NOT NULL,
    categoria VARCHAR(50) DEFAULT 'geral',
    descricao TEXT,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Períodos
CREATE TABLE IF NOT EXISTS periodos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    periodo VARCHAR(10) NOT NULL UNIQUE,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Ensalamento
CREATE TABLE IF NOT EXISTS ensalamento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    turma_id INT NOT NULL,
    sala_id INT,
    dia_semana ENUM('segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado', 'domingo'),
    horario_inicio TIME,
    horario_fim TIME,
    status ENUM('pendente', 'alocado', 'conflito', 'cancelado') DEFAULT 'pendente',
    eficiencia DECIMAL(5,2),
    algoritmo_usado VARCHAR(50),
    observacoes TEXT,
    periodo VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (turma_id) REFERENCES turmas(id) ON DELETE CASCADE,
    FOREIGN KEY (sala_id) REFERENCES salas(id) ON DELETE SET NULL,
    
    INDEX idx_turma (turma_id),
    INDEX idx_sala (sala_id),
    INDEX idx_periodo (periodo),
    INDEX idx_status (status),
    INDEX idx_dia_horario (dia_semana, horario_inicio)
);

-- Tabela de Logs
CREATE TABLE IF NOT EXISTS logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(100),
    acao VARCHAR(100) NOT NULL,
    tabela VARCHAR(50),
    registro_id INT,
    dados_anteriores JSON,
    dados_novos JSON,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_usuario (usuario),
    INDEX idx_acao (acao),
    INDEX idx_created_at (created_at)
);

