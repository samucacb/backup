-- Script para atualizar banco de dados com as novas estruturas

-- Remover colunas JSON antigas se existirem
ALTER TABLE turmas DROP COLUMN IF EXISTS dias_semana;
ALTER TABLE turmas DROP COLUMN IF EXISTS horarios;

-- Adicionar novas colunas na tabela turmas
ALTER TABLE turmas 
ADD COLUMN IF NOT EXISTS carga_horaria INT DEFAULT 0,
ADD COLUMN IF NOT EXISTS horario_inicio TIME,
ADD COLUMN IF NOT EXISTS horario_fim TIME,
ADD COLUMN IF NOT EXISTS segunda BOOLEAN DEFAULT 0,
ADD COLUMN IF NOT EXISTS terca BOOLEAN DEFAULT 0,
ADD COLUMN IF NOT EXISTS quarta BOOLEAN DEFAULT 0,
ADD COLUMN IF NOT EXISTS quinta BOOLEAN DEFAULT 0,
ADD COLUMN IF NOT EXISTS sexta BOOLEAN DEFAULT 0,
ADD COLUMN IF NOT EXISTS sabado BOOLEAN DEFAULT 0,
ADD COLUMN IF NOT EXISTS turno ENUM('matutino', 'vespertino', 'noturno', 'integral') DEFAULT 'matutino';

-- Adicionar coluna categoria na tabela configuracoes
ALTER TABLE configuracoes 
ADD COLUMN IF NOT EXISTS categoria VARCHAR(50) DEFAULT 'geral';

-- Adicionar índices
CREATE INDEX IF NOT EXISTS idx_turno ON turmas(turno);
CREATE INDEX IF NOT EXISTS idx_categoria ON configuracoes(categoria);

-- Inserir dados de exemplo para teste
INSERT IGNORE INTO salas (codigo, nome, capacidade, tipo, ativo) VALUES 
('S001', 'Sala 1', 30, 'teorica', 1),
('S002', 'Sala 2', 25, 'teorica', 1),
('L001', 'Lab 1', 20, 'laboratorio', 1);

INSERT IGNORE INTO turmas (codigo, nome, curso, periodo, professor, num_alunos, segunda, terca, quinta, turno, ativo) VALUES 
('T001', 'Matemática I', 'Engenharia', '2025.1', 'Prof. Silva', 25, 1, 1, 1, 'matutino', 1),
('T002', 'Física I', 'Engenharia', '2025.1', 'Prof. Santos', 30, 0, 1, 0, 'vespertino', 1);

INSERT IGNORE INTO ensalamento (turma_id, sala_id, status) VALUES 
(1, 1, 'alocada'),
(2, 2, 'alocada');

SELECT 'Banco de dados atualizado com sucesso!' as status;
