-- Script para atualizar banco de dados com novas colunas

-- Adicionar coluna categoria na tabela configuracoes (se não existir)
ALTER TABLE configuracoes 
ADD COLUMN IF NOT EXISTS categoria VARCHAR(50) DEFAULT 'geral';

-- Adicionar índice para categoria
CREATE INDEX IF NOT EXISTS idx_categoria ON configuracoes(categoria);

-- Adicionar colunas na tabela turmas (se não existirem)
ALTER TABLE turmas 
ADD COLUMN IF NOT EXISTS dias_semana JSON,
ADD COLUMN IF NOT EXISTS turno ENUM('matutino', 'vespertino', 'noturno', 'integral') DEFAULT 'matutino';

-- Adicionar índice para turno
CREATE INDEX IF NOT EXISTS idx_turno ON turmas(turno);

-- Verificar se as alterações foram aplicadas
SELECT 'Colunas adicionadas com sucesso!' as status;
