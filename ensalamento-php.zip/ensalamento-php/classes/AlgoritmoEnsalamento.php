<?php
/**
 * Classe AlgoritmoEnsalamento
 * Implementa algoritmos de otimização para ensalamento
 */

require_once __DIR__ . '/Sala.php';
require_once __DIR__ . '/Turma.php';
require_once __DIR__ . '/Ensalamento.php';

class AlgoritmoEnsalamento {
    private $db;
    private $sala;
    private $turma;
    private $ensalamento;
    private $configuracoes;
    
    public function __construct($database = null) {
        global $database as $db;
        $this->db = $database ?: $db;
        $this->sala = new Sala($this->db);
        $this->turma = new Turma($this->db);
        $this->ensalamento = new Ensalamento($this->db);
        $this->carregarConfiguracoes();
    }
    
    private function carregarConfiguracoes() {
        $configs = $this->db->fetchAll("SELECT chave, valor, tipo FROM configuracoes");
        $this->configuracoes = [];
        
        foreach ($configs as $config) {
            $valor = $config['valor'];
            switch ($config['tipo']) {
                case 'int':
                    $valor = (int)$valor;
                    break;
                case 'float':
                    $valor = (float)$valor;
                    break;
                case 'boolean':
                    $valor = filter_var($valor, FILTER_VALIDATE_BOOLEAN);
                    break;
                case 'json':
                    $valor = json_decode($valor, true);
                    break;
            }
            $this->configuracoes[$config['chave']] = $valor;
        }
    }
    
    public function executarEnsalamento($periodo, $algoritmo = 'otimizado') {
        $inicio = microtime(true);
        
        $resultado = [
            'periodo' => $periodo,
            'algoritmo' => $algoritmo,
            'inicio' => date('Y-m-d H:i:s'),
            'turmas_processadas' => 0,
            'turmas_alocadas' => 0,
            'turmas_conflito' => 0,
            'eficiencia_media' => 0,
            'tempo_processamento' => 0,
            'detalhes' => []
        ];
        
        try {
            // Limpar ensalamentos anteriores do período
            $this->ensalamento->limparPeriodo($periodo);
            
            // Obter turmas sem ensalamento
            $turmas = $this->turma->obterSemEnsalamento($periodo);
            $resultado['turmas_processadas'] = count($turmas);
            
            if (empty($turmas)) {
                $resultado['mensagem'] = 'Nenhuma turma encontrada para ensalamento';
                return $resultado;
            }
            
            // Executar algoritmo escolhido
            switch ($algoritmo) {
                case 'guloso':
                    $alocacoes = $this->algoritmoGuloso($turmas, $periodo);
                    break;
                case 'otimizado':
                    $alocacoes = $this->algoritmoOtimizado($turmas, $periodo);
                    break;
                case 'hibrido':
                    $alocacoes = $this->algoritmoHibrido($turmas, $periodo);
                    break;
                default:
                    throw new Exception("Algoritmo não reconhecido: $algoritmo");
            }
            
            // Salvar resultados
            $eficiencias = [];
            foreach ($alocacoes as $alocacao) {
                $id = $this->ensalamento->criar($alocacao);
                $alocacao['id'] = $id;
                $resultado['detalhes'][] = $alocacao;
                
                if ($alocacao['status'] == 'alocado') {
                    $resultado['turmas_alocadas']++;
                    $eficiencias[] = $alocacao['eficiencia'];
                } else {
                    $resultado['turmas_conflito']++;
                }
            }
            
            $resultado['eficiencia_media'] = !empty($eficiencias) ? array_sum($eficiencias) / count($eficiencias) : 0;
            $resultado['tempo_processamento'] = round((microtime(true) - $inicio) * 1000, 2);
            $resultado['sucesso'] = true;
            
        } catch (Exception $e) {
            $resultado['sucesso'] = false;
            $resultado['erro'] = $e->getMessage();
            $resultado['tempo_processamento'] = round((microtime(true) - $inicio) * 1000, 2);
        }
        
        return $resultado;
    }
    
    private function algoritmoGuloso($turmas, $periodo) {
        $alocacoes = [];
        
        // Ordenar turmas por prioridade e número de alunos
        usort($turmas, function($a, $b) {
            if ($a['prioridade'] != $b['prioridade']) {
                return $b['prioridade'] - $a['prioridade'];
            }
            return $b['num_alunos'] - $a['num_alunos'];
        });
        
        foreach ($turmas as $turma) {
            $melhor_alocacao = $this->encontrarMelhorSala($turma, $periodo);
            $alocacoes[] = $melhor_alocacao;
        }
        
        return $alocacoes;
    }
    
    private function algoritmoOtimizado($turmas, $periodo) {
        $alocacoes = [];
        $tentativas_maximas = $this->configuracoes['max_tentativas_alocacao'] ?? 5;
        
        // Ordenar turmas por dificuldade de alocação (menos salas compatíveis primeiro)
        $turmas_com_score = [];
        foreach ($turmas as $turma) {
            $salas_compativeis = $this->contarSalasCompativeis($turma);
            $turmas_com_score[] = [
                'turma' => $turma,
                'dificuldade' => $salas_compativeis,
                'prioridade' => $turma['prioridade']
            ];
        }
        
        usort($turmas_com_score, function($a, $b) {
            if ($a['prioridade'] != $b['prioridade']) {
                return $b['prioridade'] - $a['prioridade'];
            }
            return $a['dificuldade'] - $b['dificuldade'];
        });
        
        foreach ($turmas_com_score as $item) {
            $turma = $item['turma'];
            $melhor_alocacao = null;
            $melhor_score = -1;
            
            // Tentar múltiplas opções de horário
            $horarios_possiveis = $this->gerarHorariosPossiveis($turma);
            
            foreach ($horarios_possiveis as $horario) {
                $salas_disponiveis = $this->sala->buscarDisponiveis(
                    $horario['dia_semana'],
                    $horario['horario_inicio'],
                    $horario['horario_fim'],
                    $periodo,
                    $turma['recursos_necessarios']
                );
                
                foreach ($salas_disponiveis as $sala) {
                    $score = $this->calcularScore($turma, $sala, $horario);
                    
                    if ($score > $melhor_score) {
                        $melhor_score = $score;
                        $melhor_alocacao = [
                            'turma_id' => $turma['id'],
                            'sala_id' => $sala['id'],
                            'dia_semana' => $horario['dia_semana'],
                            'horario_inicio' => $horario['horario_inicio'],
                            'horario_fim' => $horario['horario_fim'],
                            'status' => 'alocado',
                            'eficiencia' => $this->sala->calcularEficiencia($sala['capacidade'], $turma['num_alunos']),
                            'algoritmo_usado' => 'otimizado',
                            'periodo' => $periodo,
                            'observacoes' => "Score: $score"
                        ];
                    }
                }
            }
            
            if (!$melhor_alocacao) {
                $melhor_alocacao = [
                    'turma_id' => $turma['id'],
                    'sala_id' => null,
                    'dia_semana' => null,
                    'horario_inicio' => null,
                    'horario_fim' => null,
                    'status' => 'conflito',
                    'eficiencia' => 0,
                    'algoritmo_usado' => 'otimizado',
                    'periodo' => $periodo,
                    'observacoes' => 'Nenhuma sala disponível encontrada'
                ];
            }
            
            $alocacoes[] = $melhor_alocacao;
        }
        
        return $alocacoes;
    }
    
    private function algoritmoHibrido($turmas, $periodo) {
        // Combina guloso para turmas de alta prioridade e otimizado para o resto
        $turmas_alta_prioridade = array_filter($turmas, function($t) { return $t['prioridade'] >= 3; });
        $turmas_normal = array_filter($turmas, function($t) { return $t['prioridade'] < 3; });
        
        $alocacoes = [];
        
        // Primeira fase: algoritmo guloso para alta prioridade
        $alocacoes_alta = $this->algoritmoGuloso($turmas_alta_prioridade, $periodo);
        $alocacoes = array_merge($alocacoes, $alocacoes_alta);
        
        // Segunda fase: algoritmo otimizado para o resto
        $alocacoes_normal = $this->algoritmoOtimizado($turmas_normal, $periodo);
        $alocacoes = array_merge($alocacoes, $alocacoes_normal);
        
        return $alocacoes;
    }
    
    private function encontrarMelhorSala($turma, $periodo) {
        $horarios_possiveis = $this->gerarHorariosPossiveis($turma);
        
        foreach ($horarios_possiveis as $horario) {
            $salas_disponiveis = $this->sala->buscarDisponiveis(
                $horario['dia_semana'],
                $horario['horario_inicio'],
                $horario['horario_fim'],
                $periodo,
                $turma['recursos_necessarios']
            );
            
            if (!empty($salas_disponiveis)) {
                // Escolher sala com melhor eficiência
                $melhor_sala = null;
                $melhor_eficiencia = -1;
                
                foreach ($salas_disponiveis as $sala) {
                    $eficiencia = $this->sala->calcularEficiencia($sala['capacidade'], $turma['num_alunos']);
                    if ($eficiencia > $melhor_eficiencia) {
                        $melhor_eficiencia = $eficiencia;
                        $melhor_sala = $sala;
                    }
                }
                
                return [
                    'turma_id' => $turma['id'],
                    'sala_id' => $melhor_sala['id'],
                    'dia_semana' => $horario['dia_semana'],
                    'horario_inicio' => $horario['horario_inicio'],
                    'horario_fim' => $horario['horario_fim'],
                    'status' => 'alocado',
                    'eficiencia' => $melhor_eficiencia,
                    'algoritmo_usado' => 'guloso',
                    'periodo' => $periodo
                ];
            }
        }
        
        // Não encontrou sala disponível
        return [
            'turma_id' => $turma['id'],
            'sala_id' => null,
            'dia_semana' => null,
            'horario_inicio' => null,
            'horario_fim' => null,
            'status' => 'conflito',
            'eficiencia' => 0,
            'algoritmo_usado' => 'guloso',
            'periodo' => $periodo,
            'observacoes' => 'Nenhuma sala disponível'
        ];
    }
    
    private function gerarHorariosPossiveis($turma) {
        $horarios = [];
        
        // Primeiro, tentar horários preferidos
        if (!empty($turma['horarios_preferidos'])) {
            foreach ($turma['horarios_preferidos'] as $horario_str) {
                $horario = $this->turma->parseHorarioPreferido($horario_str);
                if ($horario) {
                    $horarios[] = $horario;
                }
            }
        }
        
        // Se não tem preferidos ou não conseguiu alocar, gerar horários padrão
        if (empty($horarios)) {
            $dias = ['segunda', 'terca', 'quarta', 'quinta', 'sexta'];
            $horarios_padrao = [
                ['inicio' => '08:00', 'fim' => '10:00'],
                ['inicio' => '10:00', 'fim' => '12:00'],
                ['inicio' => '14:00', 'fim' => '16:00'],
                ['inicio' => '16:00', 'fim' => '18:00'],
                ['inicio' => '19:00', 'fim' => '21:00'],
                ['inicio' => '21:00', 'fim' => '23:00']
            ];
            
            foreach ($dias as $dia) {
                foreach ($horarios_padrao as $horario) {
                    $horarios[] = [
                        'dia_semana' => $dia,
                        'horario_inicio' => $horario['inicio'],
                        'horario_fim' => $horario['fim']
                    ];
                }
            }
        }
        
        return $horarios;
    }
    
    private function calcularScore($turma, $sala, $horario) {
        $peso_eficiencia = $this->configuracoes['peso_eficiencia'] ?? 0.4;
        $peso_prioridade = $this->configuracoes['peso_prioridade'] ?? 0.3;
        $peso_preferencia = $this->configuracoes['peso_preferencia'] ?? 0.3;
        
        // Score de eficiência (0-100)
        $eficiencia = $this->sala->calcularEficiencia($sala['capacidade'], $turma['num_alunos']);
        
        // Score de prioridade (0-100)
        $prioridade = ($turma['prioridade'] / 10) * 100;
        
        // Score de preferência (0-100)
        $preferencia = $this->calcularScorePreferencia($turma, $horario);
        
        // Score final ponderado
        $score = ($eficiencia * $peso_eficiencia) + 
                 ($prioridade * $peso_prioridade) + 
                 ($preferencia * $peso_preferencia);
        
        return round($score, 2);
    }
    
    private function calcularScorePreferencia($turma, $horario) {
        if (empty($turma['horarios_preferidos'])) {
            return 50; // Score neutro se não tem preferência
        }
        
        $horario_atual = $horario['dia_semana'] . ':' . $horario['horario_inicio'] . '-' . $horario['horario_fim'];
        
        foreach ($turma['horarios_preferidos'] as $preferido) {
            if ($preferido == $horario_atual) {
                return 100; // Horário exato preferido
            }
            
            // Verificar se pelo menos o dia coincide
            $dia_preferido = explode(':', $preferido)[0];
            if ($dia_preferido == $horario['dia_semana']) {
                return 75; // Mesmo dia, horário diferente
            }
        }
        
        return 25; // Não coincide com preferências
    }
    
    private function contarSalasCompativeis($turma) {
        $recursos_necessarios = $turma['recursos_necessarios'];
        $tipo_aula = $turma['tipo_aula'];
        
        // Mapear tipos de aula para tipos de sala compatíveis
        $tipos_compativeis = [
            'teorica' => ['comum', 'auditorio'],
            'pratica' => ['pratica', 'laboratorio'],
            'laboratorio' => ['laboratorio'],
            'seminario' => ['comum', 'auditorio'],
            'estagio' => ['pratica', 'laboratorio']
        ];
        
        $tipos_sala = $tipos_compativeis[$tipo_aula] ?? ['comum'];
        
        $sql = "
            SELECT COUNT(*) as total
            FROM salas 
            WHERE ativa = 1 
            AND capacidade >= :num_alunos
            AND tipo IN ('" . implode("','", $tipos_sala) . "')
        ";
        
        $result = $this->db->fetch($sql, ['num_alunos' => $turma['num_alunos']]);
        return $result['total'] ?? 0;
    }
    
    public function calcularPontoOtimoDobra($turma_id) {
        return $this->turma->calcularPontoOtimoDobra($turma_id);
    }
    
    public function obterEstatisticasEnsalamento($periodo) {
        return $this->ensalamento->obterEstatisticas($periodo);
    }
    
    public function validarEnsalamento($periodo) {
        return $this->ensalamento->validarPeriodo($periodo);
    }
}
?>

