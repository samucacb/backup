<?php
/**
 * Classe Ensalamento
 * Gerencia operações relacionadas aos resultados de ensalamento
 */

require_once __DIR__ . '/../config/database.php';

class Ensalamento {
    private $db;
    
    public function __construct($database = null) {
        global $database as $db;
        $this->db = $database ?: $db;
    }
    
    public function listar($filtros = []) {
        $where = ['1=1'];
        $params = [];
        
        if (!empty($filtros['periodo'])) {
            $where[] = 'e.periodo = :periodo';
            $params['periodo'] = $filtros['periodo'];
        }
        
        if (!empty($filtros['status'])) {
            $where[] = 'e.status = :status';
            $params['status'] = $filtros['status'];
        }
        
        if (!empty($filtros['dia_semana'])) {
            $where[] = 'e.dia_semana = :dia_semana';
            $params['dia_semana'] = $filtros['dia_semana'];
        }
        
        if (!empty($filtros['sala_id'])) {
            $where[] = 'e.sala_id = :sala_id';
            $params['sala_id'] = $filtros['sala_id'];
        }
        
        $sql = "
            SELECT 
                e.*,
                t.codigo as turma_codigo,
                t.nome as turma_nome,
                t.num_alunos,
                t.professor,
                t.curso,
                s.nome as sala_nome,
                s.capacidade as sala_capacidade,
                s.tipo as sala_tipo,
                s.localizacao as sala_localizacao
            FROM ensalamento e
            JOIN turmas t ON e.turma_id = t.id
            LEFT JOIN salas s ON e.sala_id = s.id
            WHERE " . implode(' AND ', $where) . "
            ORDER BY e.dia_semana, e.horario_inicio, t.codigo
        ";
        
        return $this->db->fetchAll($sql, $params);
    }
    
    public function buscarPorId($id) {
        $sql = "
            SELECT 
                e.*,
                t.codigo as turma_codigo,
                t.nome as turma_nome,
                t.num_alunos,
                t.professor,
                t.curso,
                s.nome as sala_nome,
                s.capacidade as sala_capacidade,
                s.tipo as sala_tipo,
                s.localizacao as sala_localizacao
            FROM ensalamento e
            JOIN turmas t ON e.turma_id = t.id
            LEFT JOIN salas s ON e.sala_id = s.id
            WHERE e.id = :id
        ";
        
        return $this->db->fetch($sql, ['id' => $id]);
    }
    
    public function criar($dados) {
        $dados_ensalamento = [
            'turma_id' => $dados['turma_id'],
            'sala_id' => $dados['sala_id'],
            'dia_semana' => $dados['dia_semana'],
            'horario_inicio' => $dados['horario_inicio'],
            'horario_fim' => $dados['horario_fim'],
            'status' => $dados['status'] ?? 'pendente',
            'eficiencia' => $dados['eficiencia'] ?? null,
            'algoritmo_usado' => $dados['algoritmo_usado'] ?? null,
            'observacoes' => $dados['observacoes'] ?? null,
            'periodo' => $dados['periodo']
        ];
        
        return $this->db->insert('ensalamento', $dados_ensalamento);
    }
    
    public function atualizar($id, $dados) {
        $dados_ensalamento = [];
        
        if (isset($dados['sala_id'])) $dados_ensalamento['sala_id'] = $dados['sala_id'];
        if (isset($dados['dia_semana'])) $dados_ensalamento['dia_semana'] = $dados['dia_semana'];
        if (isset($dados['horario_inicio'])) $dados_ensalamento['horario_inicio'] = $dados['horario_inicio'];
        if (isset($dados['horario_fim'])) $dados_ensalamento['horario_fim'] = $dados['horario_fim'];
        if (isset($dados['status'])) $dados_ensalamento['status'] = $dados['status'];
        if (isset($dados['eficiencia'])) $dados_ensalamento['eficiencia'] = $dados['eficiencia'];
        if (isset($dados['observacoes'])) $dados_ensalamento['observacoes'] = $dados['observacoes'];
        
        return $this->db->update('ensalamento', $dados_ensalamento, 'id = :id', ['id' => $id]);
    }
    
    public function excluir($id) {
        return $this->db->delete('ensalamento', 'id = :id', ['id' => $id]);
    }
    
    public function limparPeriodo($periodo) {
        return $this->db->delete('ensalamento', 'periodo = :periodo', ['periodo' => $periodo]);
    }
    
    public function obterGradePorSala($sala_id, $periodo) {
        $sql = "
            SELECT 
                e.*,
                t.codigo as turma_codigo,
                t.nome as turma_nome,
                t.professor
            FROM ensalamento e
            JOIN turmas t ON e.turma_id = t.id
            WHERE e.sala_id = :sala_id 
            AND e.periodo = :periodo
            AND e.status = 'alocado'
            ORDER BY e.dia_semana, e.horario_inicio
        ";
        
        return $this->db->fetchAll($sql, ['sala_id' => $sala_id, 'periodo' => $periodo]);
    }
    
    public function obterGradePorTurma($turma_id, $periodo) {
        $sql = "
            SELECT 
                e.*,
                s.nome as sala_nome,
                s.localizacao as sala_localizacao
            FROM ensalamento e
            LEFT JOIN salas s ON e.sala_id = s.id
            WHERE e.turma_id = :turma_id 
            AND e.periodo = :periodo
            ORDER BY e.dia_semana, e.horario_inicio
        ";
        
        return $this->db->fetchAll($sql, ['turma_id' => $turma_id, 'periodo' => $periodo]);
    }
    
    public function obterGradeCompleta($periodo) {
        $sql = "
            SELECT 
                e.dia_semana,
                e.horario_inicio,
                e.horario_fim,
                s.nome as sala_nome,
                t.codigo as turma_codigo,
                t.nome as turma_nome,
                t.professor,
                e.status
            FROM ensalamento e
            JOIN turmas t ON e.turma_id = t.id
            LEFT JOIN salas s ON e.sala_id = s.id
            WHERE e.periodo = :periodo
            ORDER BY e.dia_semana, e.horario_inicio, s.nome
        ";
        
        $resultados = $this->db->fetchAll($sql, ['periodo' => $periodo]);
        
        // Organizar em estrutura de grade
        $grade = [];
        $dias = ['segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado'];
        $horarios = [
            '08:00', '09:00', '10:00', '11:00', '12:00',
            '13:00', '14:00', '15:00', '16:00', '17:00',
            '18:00', '19:00', '20:00', '21:00', '22:00'
        ];
        
        foreach ($dias as $dia) {
            $grade[$dia] = [];
            foreach ($horarios as $horario) {
                $grade[$dia][$horario] = [];
            }
        }
        
        foreach ($resultados as $aula) {
            $dia = $aula['dia_semana'];
            $hora_inicio = substr($aula['horario_inicio'], 0, 5);
            
            if (isset($grade[$dia][$hora_inicio])) {
                $grade[$dia][$hora_inicio][] = $aula;
            }
        }
        
        return $grade;
    }
    
    public function verificarConflitos($periodo) {
        $sql = "
            SELECT 
                e1.id as ensalamento1_id,
                e2.id as ensalamento2_id,
                e1.sala_id,
                e1.dia_semana,
                e1.horario_inicio,
                e1.horario_fim,
                t1.codigo as turma1_codigo,
                t2.codigo as turma2_codigo,
                s.nome as sala_nome
            FROM ensalamento e1
            JOIN ensalamento e2 ON e1.sala_id = e2.sala_id 
                AND e1.dia_semana = e2.dia_semana
                AND e1.id != e2.id
                AND e1.periodo = e2.periodo
                AND (e1.horario_inicio < e2.horario_fim AND e1.horario_fim > e2.horario_inicio)
            JOIN turmas t1 ON e1.turma_id = t1.id
            JOIN turmas t2 ON e2.turma_id = t2.id
            JOIN salas s ON e1.sala_id = s.id
            WHERE e1.periodo = :periodo
            AND e1.status = 'alocado'
            AND e2.status = 'alocado'
            ORDER BY e1.dia_semana, e1.horario_inicio
        ";
        
        return $this->db->fetchAll($sql, ['periodo' => $periodo]);
    }
    
    public function obterEstatisticas($periodo) {
        $sql_geral = "
            SELECT 
                COUNT(*) as total_ensalamentos,
                SUM(CASE WHEN status = 'alocado' THEN 1 ELSE 0 END) as alocados,
                SUM(CASE WHEN status = 'conflito' THEN 1 ELSE 0 END) as conflitos,
                SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) as pendentes,
                AVG(CASE WHEN eficiencia IS NOT NULL THEN eficiencia END) as eficiencia_media,
                COUNT(DISTINCT sala_id) as salas_utilizadas,
                COUNT(DISTINCT turma_id) as turmas_processadas
            FROM ensalamento 
            WHERE periodo = :periodo
        ";
        
        $estatisticas = $this->db->fetch($sql_geral, ['periodo' => $periodo]);
        
        // Estatísticas por dia da semana
        $sql_dias = "
            SELECT 
                dia_semana,
                COUNT(*) as total,
                SUM(CASE WHEN status = 'alocado' THEN 1 ELSE 0 END) as alocados
            FROM ensalamento 
            WHERE periodo = :periodo
            GROUP BY dia_semana
            ORDER BY FIELD(dia_semana, 'segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado', 'domingo')
        ";
        
        $estatisticas['por_dia'] = $this->db->fetchAll($sql_dias, ['periodo' => $periodo]);
        
        // Estatísticas por horário
        $sql_horarios = "
            SELECT 
                horario_inicio,
                COUNT(*) as total,
                SUM(CASE WHEN status = 'alocado' THEN 1 ELSE 0 END) as alocados
            FROM ensalamento 
            WHERE periodo = :periodo
            GROUP BY horario_inicio
            ORDER BY horario_inicio
        ";
        
        $estatisticas['por_horario'] = $this->db->fetchAll($sql_horarios, ['periodo' => $periodo]);
        
        // Taxa de ocupação das salas
        $sql_ocupacao = "
            SELECT 
                s.nome as sala_nome,
                s.capacidade,
                COUNT(e.id) as aulas_alocadas,
                AVG(e.eficiencia) as eficiencia_media,
                ROUND((COUNT(e.id) * 100.0 / (5 * 8)), 2) as taxa_ocupacao_percent
            FROM salas s
            LEFT JOIN ensalamento e ON s.id = e.sala_id 
                AND e.periodo = :periodo 
                AND e.status = 'alocado'
            WHERE s.ativa = 1
            GROUP BY s.id, s.nome, s.capacidade
            ORDER BY taxa_ocupacao_percent DESC
        ";
        
        $estatisticas['ocupacao_salas'] = $this->db->fetchAll($sql_ocupacao, ['periodo' => $periodo]);
        
        return $estatisticas;
    }
    
    public function validarPeriodo($periodo) {
        $problemas = [];
        
        // Verificar conflitos de horário
        $conflitos = $this->verificarConflitos($periodo);
        if (!empty($conflitos)) {
            $problemas['conflitos_horario'] = $conflitos;
        }
        
        // Verificar turmas sem alocação
        $sql_sem_alocacao = "
            SELECT t.id, t.codigo, t.nome
            FROM turmas t
            LEFT JOIN ensalamento e ON t.id = e.turma_id AND e.periodo = :periodo AND e.status = 'alocado'
            WHERE t.periodo = :periodo AND e.id IS NULL
        ";
        
        $sem_alocacao = $this->db->fetchAll($sql_sem_alocacao, ['periodo' => $periodo]);
        if (!empty($sem_alocacao)) {
            $problemas['turmas_sem_alocacao'] = $sem_alocacao;
        }
        
        // Verificar superlotação
        $sql_superlotacao = "
            SELECT 
                e.id,
                t.codigo,
                t.nome as turma_nome,
                t.num_alunos,
                s.nome as sala_nome,
                s.capacidade,
                ROUND((t.num_alunos * 100.0 / s.capacidade), 2) as percentual_ocupacao
            FROM ensalamento e
            JOIN turmas t ON e.turma_id = t.id
            JOIN salas s ON e.sala_id = s.id
            WHERE e.periodo = :periodo 
            AND e.status = 'alocado'
            AND t.num_alunos > s.capacidade
        ";
        
        $superlotacao = $this->db->fetchAll($sql_superlotacao, ['periodo' => $periodo]);
        if (!empty($superlotacao)) {
            $problemas['superlotacao'] = $superlotacao;
        }
        
        return [
            'valido' => empty($problemas),
            'problemas' => $problemas,
            'total_problemas' => count($problemas)
        ];
    }
    
    public function exportarGrade($periodo, $formato = 'array') {
        $grade = $this->obterGradeCompleta($periodo);
        
        switch ($formato) {
            case 'csv':
                return $this->exportarCSV($grade, $periodo);
            case 'json':
                return json_encode($grade, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
            default:
                return $grade;
        }
    }
    
    private function exportarCSV($grade, $periodo) {
        $csv = "Período: $periodo\n";
        $csv .= "Dia,Horário,Sala,Turma,Professor,Status\n";
        
        foreach ($grade as $dia => $horarios) {
            foreach ($horarios as $horario => $aulas) {
                if (empty($aulas)) {
                    continue;
                }
                
                foreach ($aulas as $aula) {
                    $csv .= sprintf(
                        "%s,%s,%s,%s,%s,%s\n",
                        $dia,
                        $horario,
                        $aula['sala_nome'] ?? 'N/A',
                        $aula['turma_codigo'] . ' - ' . $aula['turma_nome'],
                        $aula['professor'] ?? 'N/A',
                        $aula['status']
                    );
                }
            }
        }
        
        return $csv;
    }
    
    public function obterStatusPeriodo($periodo) {
        $estatisticas = $this->obterEstatisticas($periodo);
        $validacao = $this->validarPeriodo($periodo);
        
        $total = $estatisticas['total_ensalamentos'] ?? 0;
        $alocados = $estatisticas['alocados'] ?? 0;
        $conflitos = $estatisticas['conflitos'] ?? 0;
        
        $status = 'incompleto';
        if ($total > 0) {
            if ($conflitos == 0 && $alocados == $total) {
                $status = 'completo';
            } elseif ($alocados > 0) {
                $status = 'parcial';
            }
        }
        
        return [
            'periodo' => $periodo,
            'status' => $status,
            'total_ensalamentos' => $total,
            'alocados' => $alocados,
            'conflitos' => $conflitos,
            'pendentes' => $estatisticas['pendentes'] ?? 0,
            'eficiencia_media' => round($estatisticas['eficiencia_media'] ?? 0, 2),
            'salas_utilizadas' => $estatisticas['salas_utilizadas'] ?? 0,
            'turmas_processadas' => $estatisticas['turmas_processadas'] ?? 0,
            'validacao' => $validacao
        ];
    }
}
?>

