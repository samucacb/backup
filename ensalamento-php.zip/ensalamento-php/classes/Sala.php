<?php
/**
 * Classe Sala
 * Gerencia operações relacionadas às salas
 */

require_once __DIR__ . '/../config/database.php';

class Sala {
    private $db;
    
    public function __construct($database = null) {
        global $database as $db;
        $this->db = $database ?: $db;
    }
    
    public function listar($filtros = []) {
        $where = ['ativa = 1'];
        $params = [];
        
        if (!empty($filtros['tipo'])) {
            $where[] = 'tipo = :tipo';
            $params['tipo'] = $filtros['tipo'];
        }
        
        if (!empty($filtros['capacidade_min'])) {
            $where[] = 'capacidade >= :capacidade_min';
            $params['capacidade_min'] = $filtros['capacidade_min'];
        }
        
        if (!empty($filtros['recursos'])) {
            $where[] = 'JSON_CONTAINS(recursos, :recursos)';
            $params['recursos'] = json_encode($filtros['recursos']);
        }
        
        $sql = "SELECT * FROM salas WHERE " . implode(' AND ', $where) . " ORDER BY nome";
        
        $salas = $this->db->fetchAll($sql, $params);
        
        // Decodificar JSON dos recursos
        foreach ($salas as &$sala) {
            $sala['recursos'] = json_decode($sala['recursos'], true) ?: [];
        }
        
        return $salas;
    }
    
    public function buscarPorId($id) {
        $sala = $this->db->fetch("SELECT * FROM salas WHERE id = :id", ['id' => $id]);
        
        if ($sala) {
            $sala['recursos'] = json_decode($sala['recursos'], true) ?: [];
        }
        
        return $sala;
    }
    
    public function criar($dados) {
        $dados_sala = [
            'nome' => $dados['nome'],
            'capacidade' => (int)$dados['capacidade'],
            'tipo' => $dados['tipo'],
            'recursos' => json_encode($dados['recursos'] ?? []),
            'localizacao' => $dados['localizacao'] ?? '',
            'ativa' => true
        ];
        
        return $this->db->insert('salas', $dados_sala);
    }
    
    public function atualizar($id, $dados) {
        $dados_sala = [];
        
        if (isset($dados['nome'])) $dados_sala['nome'] = $dados['nome'];
        if (isset($dados['capacidade'])) $dados_sala['capacidade'] = (int)$dados['capacidade'];
        if (isset($dados['tipo'])) $dados_sala['tipo'] = $dados['tipo'];
        if (isset($dados['recursos'])) $dados_sala['recursos'] = json_encode($dados['recursos']);
        if (isset($dados['localizacao'])) $dados_sala['localizacao'] = $dados['localizacao'];
        if (isset($dados['ativa'])) $dados_sala['ativa'] = (bool)$dados['ativa'];
        
        return $this->db->update('salas', $dados_sala, 'id = :id', ['id' => $id]);
    }
    
    public function excluir($id) {
        // Soft delete - marca como inativa
        return $this->db->update('salas', ['ativa' => false], 'id = :id', ['id' => $id]);
    }
    
    public function buscarDisponiveis($dia_semana, $horario_inicio, $horario_fim, $periodo, $recursos_necessarios = []) {
        $sql = "
            SELECT s.* 
            FROM salas s 
            WHERE s.ativa = 1
            AND s.id NOT IN (
                SELECT DISTINCT e.sala_id 
                FROM ensalamento e 
                WHERE e.sala_id IS NOT NULL
                AND e.status = 'alocado'
                AND e.periodo = :periodo
                AND e.dia_semana = :dia_semana
                AND (
                    (e.horario_inicio < :horario_fim AND e.horario_fim > :horario_inicio)
                )
            )
        ";
        
        $params = [
            'periodo' => $periodo,
            'dia_semana' => $dia_semana,
            'horario_inicio' => $horario_inicio,
            'horario_fim' => $horario_fim
        ];
        
        $salas = $this->db->fetchAll($sql, $params);
        
        // Filtrar por recursos se necessário
        if (!empty($recursos_necessarios)) {
            $salas = array_filter($salas, function($sala) use ($recursos_necessarios) {
                $recursos_sala = json_decode($sala['recursos'], true) ?: [];
                return empty(array_diff($recursos_necessarios, $recursos_sala));
            });
        }
        
        // Decodificar recursos
        foreach ($salas as &$sala) {
            $sala['recursos'] = json_decode($sala['recursos'], true) ?: [];
        }
        
        return $salas;
    }
    
    public function calcularEficiencia($capacidade_sala, $num_alunos) {
        if ($capacidade_sala <= 0) return 0;
        
        $ocupacao = $num_alunos / $capacidade_sala;
        
        // Eficiência máxima entre 80-95% de ocupação
        if ($ocupacao >= 0.8 && $ocupacao <= 0.95) {
            return 100;
        }
        
        // Penalizar subutilização e superlotação
        if ($ocupacao < 0.8) {
            return $ocupacao * 125; // Máximo 100% em 80%
        } else {
            return max(0, 100 - (($ocupacao - 0.95) * 200));
        }
    }
    
    public function obterEstatisticas($periodo = null) {
        if (!$periodo) {
            $config = $this->db->fetch("SELECT valor FROM configuracoes WHERE chave = 'periodo_atual'");
            $periodo = $config['valor'] ?? '2025.1';
        }
        
        $sql = "
            SELECT 
                s.id,
                s.nome,
                s.capacidade,
                s.tipo,
                COUNT(e.id) as total_alocacoes,
                AVG(e.eficiencia) as eficiencia_media,
                SUM(CASE WHEN e.status = 'alocado' THEN 1 ELSE 0 END) as alocacoes_confirmadas
            FROM salas s
            LEFT JOIN ensalamento e ON s.id = e.sala_id AND e.periodo = :periodo
            WHERE s.ativa = 1
            GROUP BY s.id, s.nome, s.capacidade, s.tipo
            ORDER BY s.nome
        ";
        
        return $this->db->fetchAll($sql, ['periodo' => $periodo]);
    }
    
    public function verificarConflitos($sala_id, $dia_semana, $horario_inicio, $horario_fim, $periodo, $excluir_ensalamento_id = null) {
        $sql = "
            SELECT e.*, t.codigo, t.nome as turma_nome
            FROM ensalamento e
            JOIN turmas t ON e.turma_id = t.id
            WHERE e.sala_id = :sala_id
            AND e.periodo = :periodo
            AND e.dia_semana = :dia_semana
            AND e.status = 'alocado'
            AND (e.horario_inicio < :horario_fim AND e.horario_fim > :horario_inicio)
        ";
        
        $params = [
            'sala_id' => $sala_id,
            'periodo' => $periodo,
            'dia_semana' => $dia_semana,
            'horario_inicio' => $horario_inicio,
            'horario_fim' => $horario_fim
        ];
        
        if ($excluir_ensalamento_id) {
            $sql .= " AND e.id != :excluir_id";
            $params['excluir_id'] = $excluir_ensalamento_id;
        }
        
        return $this->db->fetchAll($sql, $params);
    }
    
    public function obterTipos() {
        return ['comum', 'laboratorio', 'auditorio', 'biblioteca', 'pratica', 'informatica'];
    }
    
    public function obterRecursosPadrao() {
        return [
            'projetor',
            'quadro_branco',
            'ar_condicionado',
            'computador',
            'som',
            'microfone',
            'internet',
            'bancadas',
            'pia',
            'armarios',
            'equipamentos_especializados'
        ];
    }
}
?>

