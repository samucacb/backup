<?php
/**
 * Classe Turma
 * Gerencia operações relacionadas às turmas
 */

require_once __DIR__ . '/../config/database.php';

class Turma {
    private $db;
    
    public function __construct($database = null) {
        global $database as $db;
        $this->db = $database ?: $db;
    }
    
    public function listar($filtros = []) {
        $where = ['1=1'];
        $params = [];
        
        if (!empty($filtros['periodo'])) {
            $where[] = 'periodo = :periodo';
            $params['periodo'] = $filtros['periodo'];
        }
        
        if (!empty($filtros['curso'])) {
            $where[] = 'curso = :curso';
            $params['curso'] = $filtros['curso'];
        }
        
        if (!empty($filtros['tipo_aula'])) {
            $where[] = 'tipo_aula = :tipo_aula';
            $params['tipo_aula'] = $filtros['tipo_aula'];
        }
        
        if (!empty($filtros['professor'])) {
            $where[] = 'professor LIKE :professor';
            $params['professor'] = '%' . $filtros['professor'] . '%';
        }
        
        $sql = "SELECT * FROM turmas WHERE " . implode(' AND ', $where) . " ORDER BY prioridade DESC, codigo";
        
        $turmas = $this->db->fetchAll($sql, $params);
        
        // Decodificar JSON
        foreach ($turmas as &$turma) {
            $turma['recursos_necessarios'] = json_decode($turma['recursos_necessarios'], true) ?: [];
            $turma['horarios_preferidos'] = json_decode($turma['horarios_preferidos'], true) ?: [];
        }
        
        return $turmas;
    }
    
    public function buscarPorId($id) {
        $turma = $this->db->fetch("SELECT * FROM turmas WHERE id = :id", ['id' => $id]);
        
        if ($turma) {
            $turma['recursos_necessarios'] = json_decode($turma['recursos_necessarios'], true) ?: [];
            $turma['horarios_preferidos'] = json_decode($turma['horarios_preferidos'], true) ?: [];
        }
        
        return $turma;
    }
    
    public function buscarPorCodigo($codigo) {
        $turma = $this->db->fetch("SELECT * FROM turmas WHERE codigo = :codigo", ['codigo' => $codigo]);
        
        if ($turma) {
            $turma['recursos_necessarios'] = json_decode($turma['recursos_necessarios'], true) ?: [];
            $turma['horarios_preferidos'] = json_decode($turma['horarios_preferidos'], true) ?: [];
        }
        
        return $turma;
    }
    
    public function criar($dados) {
        // Verificar se código já existe
        if ($this->buscarPorCodigo($dados['codigo'])) {
            throw new Exception("Código de turma já existe: " . $dados['codigo']);
        }
        
        $dados_turma = [
            'codigo' => $dados['codigo'],
            'nome' => $dados['nome'],
            'num_alunos' => (int)$dados['num_alunos'],
            'professor' => $dados['professor'] ?? '',
            'tipo_aula' => $dados['tipo_aula'],
            'recursos_necessarios' => json_encode($dados['recursos_necessarios'] ?? []),
            'prioridade' => (int)($dados['prioridade'] ?? 1),
            'periodo' => $dados['periodo'],
            'curso' => $dados['curso'] ?? '',
            'carga_horaria' => (int)($dados['carga_horaria'] ?? 0),
            'horarios_preferidos' => json_encode($dados['horarios_preferidos'] ?? [])
        ];
        
        return $this->db->insert('turmas', $dados_turma);
    }
    
    public function atualizar($id, $dados) {
        $dados_turma = [];
        
        if (isset($dados['codigo'])) {
            // Verificar se novo código já existe (exceto para esta turma)
            $existente = $this->db->fetch("SELECT id FROM turmas WHERE codigo = :codigo AND id != :id", 
                ['codigo' => $dados['codigo'], 'id' => $id]);
            if ($existente) {
                throw new Exception("Código de turma já existe: " . $dados['codigo']);
            }
            $dados_turma['codigo'] = $dados['codigo'];
        }
        
        if (isset($dados['nome'])) $dados_turma['nome'] = $dados['nome'];
        if (isset($dados['num_alunos'])) $dados_turma['num_alunos'] = (int)$dados['num_alunos'];
        if (isset($dados['professor'])) $dados_turma['professor'] = $dados['professor'];
        if (isset($dados['tipo_aula'])) $dados_turma['tipo_aula'] = $dados['tipo_aula'];
        if (isset($dados['recursos_necessarios'])) $dados_turma['recursos_necessarios'] = json_encode($dados['recursos_necessarios']);
        if (isset($dados['prioridade'])) $dados_turma['prioridade'] = (int)$dados['prioridade'];
        if (isset($dados['periodo'])) $dados_turma['periodo'] = $dados['periodo'];
        if (isset($dados['curso'])) $dados_turma['curso'] = $dados['curso'];
        if (isset($dados['carga_horaria'])) $dados_turma['carga_horaria'] = (int)$dados['carga_horaria'];
        if (isset($dados['horarios_preferidos'])) $dados_turma['horarios_preferidos'] = json_encode($dados['horarios_preferidos']);
        
        return $this->db->update('turmas', $dados_turma, 'id = :id', ['id' => $id]);
    }
    
    public function excluir($id) {
        // Verificar se turma tem ensalamentos
        $ensalamentos = $this->db->fetchAll("SELECT id FROM ensalamento WHERE turma_id = :id", ['id' => $id]);
        
        if (!empty($ensalamentos)) {
            throw new Exception("Não é possível excluir turma com ensalamentos associados");
        }
        
        return $this->db->delete('turmas', 'id = :id', ['id' => $id]);
    }
    
    public function obterSemEnsalamento($periodo = null) {
        if (!$periodo) {
            $config = $this->db->fetch("SELECT valor FROM configuracoes WHERE chave = 'periodo_atual'");
            $periodo = $config['valor'] ?? '2025.1';
        }
        
        $sql = "
            SELECT t.* 
            FROM turmas t
            LEFT JOIN ensalamento e ON t.id = e.turma_id AND e.periodo = :periodo AND e.status = 'alocado'
            WHERE e.id IS NULL AND t.periodo = :periodo
            ORDER BY t.prioridade DESC, t.codigo
        ";
        
        $turmas = $this->db->fetchAll($sql, ['periodo' => $periodo]);
        
        foreach ($turmas as &$turma) {
            $turma['recursos_necessarios'] = json_decode($turma['recursos_necessarios'], true) ?: [];
            $turma['horarios_preferidos'] = json_decode($turma['horarios_preferidos'], true) ?: [];
        }
        
        return $turmas;
    }
    
    public function calcularPontoOtimoDobra($turma_id) {
        $turma = $this->buscarPorId($turma_id);
        if (!$turma) return null;
        
        $num_alunos = $turma['num_alunos'];
        $tipo_aula = $turma['tipo_aula'];
        
        // Parâmetros por tipo de aula
        $parametros = [
            'teorica' => ['max_alunos' => 50, 'ideal_min' => 25, 'ideal_max' => 40],
            'pratica' => ['max_alunos' => 30, 'ideal_min' => 15, 'ideal_max' => 25],
            'laboratorio' => ['max_alunos' => 25, 'ideal_min' => 12, 'ideal_max' => 20],
            'seminario' => ['max_alunos' => 35, 'ideal_min' => 20, 'ideal_max' => 30],
            'estagio' => ['max_alunos' => 15, 'ideal_min' => 8, 'ideal_max' => 12]
        ];
        
        $param = $parametros[$tipo_aula] ?? $parametros['teorica'];
        
        $resultado = [
            'turma_id' => $turma_id,
            'num_alunos_atual' => $num_alunos,
            'tipo_aula' => $tipo_aula,
            'recomendacao' => 'manter',
            'justificativa' => '',
            'opcoes_dobra' => []
        ];
        
        if ($num_alunos > $param['max_alunos']) {
            // Necessário dobrar
            $turmas_dobradas = ceil($num_alunos / $param['ideal_max']);
            $alunos_por_turma = ceil($num_alunos / $turmas_dobradas);
            
            $resultado['recomendacao'] = 'dobrar_obrigatorio';
            $resultado['justificativa'] = "Turma excede limite máximo de {$param['max_alunos']} alunos";
            $resultado['opcoes_dobra'][] = [
                'num_turmas' => $turmas_dobradas,
                'alunos_por_turma' => $alunos_por_turma,
                'eficiencia' => $this->calcularEficienciaDobra($alunos_por_turma, $param)
            ];
            
        } elseif ($num_alunos > $param['ideal_max']) {
            // Recomendado dobrar
            $resultado['recomendacao'] = 'dobrar_recomendado';
            $resultado['justificativa'] = "Turma acima do ideal de {$param['ideal_max']} alunos";
            
            // Opção 1: Dobrar em 2
            $alunos_por_turma = ceil($num_alunos / 2);
            $resultado['opcoes_dobra'][] = [
                'num_turmas' => 2,
                'alunos_por_turma' => $alunos_por_turma,
                'eficiencia' => $this->calcularEficienciaDobra($alunos_por_turma, $param)
            ];
            
        } elseif ($num_alunos >= $param['ideal_min']) {
            $resultado['justificativa'] = "Turma dentro do tamanho ideal";
            
        } else {
            $resultado['recomendacao'] = 'juntar_recomendado';
            $resultado['justificativa'] = "Turma abaixo do ideal de {$param['ideal_min']} alunos";
        }
        
        return $resultado;
    }
    
    private function calcularEficienciaDobra($alunos_por_turma, $parametros) {
        if ($alunos_por_turma >= $parametros['ideal_min'] && $alunos_por_turma <= $parametros['ideal_max']) {
            return 100;
        } elseif ($alunos_por_turma < $parametros['ideal_min']) {
            return ($alunos_por_turma / $parametros['ideal_min']) * 100;
        } else {
            return max(0, 100 - (($alunos_por_turma - $parametros['ideal_max']) * 5));
        }
    }
    
    public function obterCursos() {
        $sql = "SELECT DISTINCT curso FROM turmas WHERE curso IS NOT NULL AND curso != '' ORDER BY curso";
        $result = $this->db->fetchAll($sql);
        return array_column($result, 'curso');
    }
    
    public function obterProfessores() {
        $sql = "SELECT DISTINCT professor FROM turmas WHERE professor IS NOT NULL AND professor != '' ORDER BY professor";
        $result = $this->db->fetchAll($sql);
        return array_column($result, 'professor');
    }
    
    public function obterTiposAula() {
        return ['teorica', 'pratica', 'laboratorio', 'seminario', 'estagio'];
    }
    
    public function obterEstatisticas($periodo = null) {
        if (!$periodo) {
            $config = $this->db->fetch("SELECT valor FROM configuracoes WHERE chave = 'periodo_atual'");
            $periodo = $config['valor'] ?? '2025.1';
        }
        
        $sql = "
            SELECT 
                COUNT(*) as total_turmas,
                SUM(num_alunos) as total_alunos,
                AVG(num_alunos) as media_alunos,
                COUNT(DISTINCT curso) as total_cursos,
                COUNT(DISTINCT professor) as total_professores
            FROM turmas 
            WHERE periodo = :periodo
        ";
        
        $estatisticas = $this->db->fetch($sql, ['periodo' => $periodo]);
        
        // Estatísticas por tipo de aula
        $sql_tipos = "
            SELECT 
                tipo_aula,
                COUNT(*) as quantidade,
                AVG(num_alunos) as media_alunos
            FROM turmas 
            WHERE periodo = :periodo
            GROUP BY tipo_aula
            ORDER BY quantidade DESC
        ";
        
        $estatisticas['por_tipo'] = $this->db->fetchAll($sql_tipos, ['periodo' => $periodo]);
        
        return $estatisticas;
    }
    
    public function parseHorarioPreferido($horario_str) {
        // Formato: "segunda:08:00-10:00"
        if (preg_match('/^(\w+):(\d{2}:\d{2})-(\d{2}:\d{2})$/', $horario_str, $matches)) {
            return [
                'dia_semana' => $matches[1],
                'horario_inicio' => $matches[2],
                'horario_fim' => $matches[3]
            ];
        }
        return null;
    }
}
?>

