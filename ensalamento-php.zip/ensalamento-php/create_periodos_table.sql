-- Script para criar tabela periodos
-- Sistema de Ensalamento PHP

CREATE TABLE `periodos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `periodo` VARCHAR(10) NOT NULL UNIQUE,
  `ativo` BOOLEAN NOT NULL DEFAULT TRUE,
  `data_criacao` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Pré-popular a tabela com os períodos que já existem nas turmas de demonstração
INSERT INTO periodos (periodo)
SELECT DISTINCT periodo FROM turmas ORDER BY periodo DESC;

