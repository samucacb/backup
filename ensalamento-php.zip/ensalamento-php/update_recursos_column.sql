-- Script para modificar coluna recursos
-- Sistema de Ensalamento PHP

ALTER TABLE salas MODIFY COLUMN recursos TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL;

